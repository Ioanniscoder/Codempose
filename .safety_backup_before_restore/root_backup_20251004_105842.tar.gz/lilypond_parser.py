import re
import music21
from music_data import extract_data_from_part
from lily_to_tiny import lily_to_tiny_notation


def _parse_tiny_pitch(pitch_str: str) -> music21.pitch.Pitch:
    """
    Parse a TinyNotation pitch string into a music21.Pitch object.
    
    Examples: 'c', 'f#', "g'", 'b-', "c,,"
    """
    # Pattern: letter + optional accidental + optional octave markers
    match = re.match(r"([a-g])([#\-]*)([',]*)", pitch_str.lower())
    if not match:
        raise ValueError(f"Cannot parse pitch: {pitch_str}")
    
    step = match.group(1).upper()
    accidentals = match.group(2)
    octave_marks = match.group(3)
    
    # Calculate octave (base = 4 for TinyNotation)
    octave = 4 + octave_marks.count("'") - octave_marks.count(",")
    
    # Create pitch
    pitch = music21.pitch.Pitch(step)
    pitch.octave = octave
    
    # Apply accidentals
    if '#' in accidentals:
        pitch.accidental = music21.pitch.Accidental('sharp')
    elif '-' in accidentals:
        pitch.accidental = music21.pitch.Accidental('flat')
    
    return pitch


def _parse_tiny_duration(dur_str: str) -> float:
    """
    Parse a TinyNotation duration string into quarter lengths.
    
    Examples: '4' → 1.0, '2' → 2.0, '8' → 0.5, '4.' → 1.5
    """
    if not dur_str:
        return 1.0  # Default quarter note
    
    # Check for dots
    has_dot = '.' in dur_str
    base_dur = dur_str.replace('.', '')
    
    if not base_dur.isdigit():
        return 1.0  # Default
    
    # Quarter length = 4.0 / duration_number
    ql = 4.0 / float(base_dur)
    
    # Dotted durations are 1.5x base
    if has_dot:
        ql *= 1.5
    
    return ql


def parse_lilypond_to_data(lily_string: str, part_name: str = "Part 1") -> dict:
    """
    Parses a LilyPond shorthand string into the standard data dictionary.
    Returns a dict: {"metadata": {...}, "parts": { part_name: [events...] }}
    
    Now uses the validated lily_to_tiny_notation() parser with correct
    relative octave logic (alphabetical tie-breaking, not shortest diatonic path).
    """
    # Basic sanitization (strip control chars that break tokenization)
    if lily_string is None:
        lily_string = ''
    lily_string = re.sub(r"[\x00-\x08\x0b-\x0c\x0e-\x1f]+", '', lily_string)

    # Use the new validated parser
    parse_result = lily_to_tiny_notation(lily_string)
    
    # Handle errors
    if not parse_result.success:
        raise ValueError(f"Parser error: {parse_result.error}")
    
    # Build music21 Part manually from tokens (to support chords)
    # music21's TinyNotation doesn't support <chord> syntax, so we parse directly
    part = music21.stream.Part()
    
    try:
        for token_info in parse_result.tokens:
            # Parse the converted TinyNotation token
            token_str = token_info.converted
            
            # Check if it's a chord
            if token_str.startswith('<'):
                # Parse chord: <pitch1 pitch2>duration
                chord_match = re.match(r'<([^>]+)>(.+)', token_str)
                if chord_match:
                    pitches_str = chord_match.group(1)  # e.g., "e g" or "d f a"
                    duration_str = chord_match.group(2)  # e.g., "2" or "4."
                    
                    # Parse each pitch in the chord
                    pitch_tokens = pitches_str.strip().split()
                    pitches = []
                    for pitch_token in pitch_tokens:
                        # Parse individual pitch (e.g., "e" or "f" or "a")
                        pitch = _parse_tiny_pitch(pitch_token)
                        pitches.append(pitch)
                    
                    # Parse duration
                    ql = _parse_tiny_duration(duration_str)
                    
                    # Create Chord object
                    chord = music21.chord.Chord(pitches, quarterLength=ql)
                    part.append(chord)
                continue
            
            # Otherwise, parse as a single note/rest using music21 TinyNotation
            try:
                tiny_obj = music21.converter.parse(f"tinynotation: {token_str}")
                for element in tiny_obj.flatten().notesAndRests:
                    part.append(element)
            except:
                # Fallback: skip unparseable tokens
                pass
        
        # Add time signature if present
        if 'time' in parse_result.directives:
            ts_str = parse_result.directives['time']
            numerator, denominator = map(int, ts_str.split('/'))
            ts = music21.meter.TimeSignature(f"{numerator}/{denominator}")
            part.insert(0, ts)
            
    except Exception as e:
        raise ValueError(f"Failed to build music21 Part from tokens: {e}")

    # Extract metadata - start with defaults
    metadata = {"title": "LilyPond Score", "composer": "Codempose"}
    
    # Extract from directives if available
    if parse_result.directives:
        for directive in parse_result.directives:
            if directive.startswith(r'\time'):
                match = re.search(r'\\time\s+(\d+/\d+)', directive)
                if match:
                    metadata["time_signature"] = match.group(1)
            elif directive.startswith(r'\key'):
                match = re.search(r'\\key\s+([A-Ga-g][#b]?)\s*(major|minor)?', directive)
                if match:
                    tonic = match.group(1)
                    mode = match.group(2) or 'major'
                    metadata["key_signature"] = {"tonic": tonic, "mode": mode}
            elif directive.startswith(r'\tempo'):
                match = re.search(r'\\tempo\s+[^=]*=(\d+)', directive)
                if match:
                    metadata["tempo"] = int(match.group(1))
    
    # Also check music21 Part for metadata (fallback)
    ts = part.getElementsByClass(music21.meter.TimeSignature)
    if ts and "time_signature" not in metadata:
        metadata["time_signature"] = ts[0].ratioString
    ks = part.getElementsByClass(music21.key.Key)
    if ks and "key_signature" not in metadata:
        k = ks[0]
        metadata["key_signature"] = {
            "tonic": getattr(k.tonic if hasattr(k, 'tonic') else k.tonicPitch, 'name', 'C'),
            "mode": getattr(k, 'mode', 'major')
        }
    tm = part.getElementsByClass(music21.tempo.MetronomeMark)
    if tm and "tempo" not in metadata:
        metadata["tempo"] = int(getattr(tm[0], 'number', 120))

    # Convert the music21 Part to the canonical event list
    # Pass TokenInfo data for event-level tracking (direct parsing only)
    events = extract_data_from_part(part, token_infos=parse_result.tokens)

    # Attach any parsing warnings to the metadata
    if parse_result.warnings:
        metadata['warnings'] = parse_result.warnings
    
    # Also store the full token tracking data in metadata for reference
    if parse_result.tokens:
        metadata['parser_tokens'] = [
            {
                'original': t.original,
                'converted': t.converted,
                'position': t.position,
                'warnings': t.warnings
            }
            for t in parse_result.tokens
        ]
    
    # Store original input for potential re-use
    metadata['original_input'] = lily_string
    
    score_data = {"metadata": metadata, "parts": {part_name: events}}
    return score_data


