# Codempose Documentation Index

## Latest Updates (October 4, 2025)

### Promotion System Update ✨ NEW
The promotion system now supports **dual-format correlation** from the start!

- **PROMOTION_WORKFLOW.md** - Complete guide to the promotion system (READ FIRST!)
- **PROMOTION_UPDATE.md** - Summary of changes from old to new workflow
- **PROMOTION_VERIFICATION.md** - Test results and verification matrix
- **PROMOTION_QUICK_REFERENCE.md** - One-page cheat sheet

**Key Change**: Study files now include both LilyPond and TinyNotation formats by default for visual comparison. The `PROMOTE_TO_TINYNOTATION` toggle controls which format is dominant (gets processed).

---

### Staff Order & Octave Fixes ✨ NEW
Resolved two issues in two-stave output:

- **FIX_COMPLETE.md** - Summary of staff ordering and melody octave fixes
- **DIAGNOSIS_STAFF_ISSUES.md** - Technical analysis of the problems
- **OPTIONS_STAFF_FIX.md** - Comparison of three solution approaches

**Key Changes**: 
- Added `reverse=True` to sorted() for correct staff order (treble top, bass bottom)
- Changed `\relative e` to `\relative e'` for correct melody octave (E4 instead of E3)

---

## Core Documentation

### Getting Started
1. **README_DOCUMENTATION.md** - Project overview and quick start guide
2. **FIRST_PY_DOCUMENTATION.md** - Understanding the first.py template structure
3. **PROMOTION_QUICK_REFERENCE.md** - Quick lookup for common tasks

### System Architecture
1. **COMPLETE_SUMMARY.md** - High-level system architecture and design
2. **RESTRUCTURE_SUMMARY.md** - How the pipeline processes study files
3. **VISUAL_SUMMARY.txt** - ASCII diagrams of the pipeline flow
4. **DUAL_FORMAT_VISUAL.txt** - Visual representation of LilyPond vs TinyNotation

### Advanced Features
1. **PROMOTION_SYSTEM.md** - Original promotion system documentation
2. **PROMOTION_WORKFLOW.md** - Updated dual-format workflow (⭐ RECOMMENDED)
3. **METADATA_TINYNOTATION_FORMAT.md** - TinyNotation metadata header format

### Development
1. **DEVELOPMENT.md** - Development guidelines and contribution guide
2. **DEVELOPER_CHANGES.md** - Changelog for code modifications
3. **RESTORATION_COMPLETE.md** - History of system restoration work

### Testing & Verification
1. **TEST_RESULTS_METADATA_TINYNOTATION.md** - Test results for metadata handling
2. **PROMOTION_VERIFICATION.md** - Verification matrix for promotion system
3. **demo_note_tracking.py** - Demonstration of note tracking system

---

## Quick Navigation

### "I want to..."

#### Create a new composition
→ Start with **first.py** as a template  
→ Read **FIRST_PY_DOCUMENTATION.md** for structure  
→ See **PROMOTION_QUICK_REFERENCE.md** for commands  

#### Understand the promotion system
→ Read **PROMOTION_WORKFLOW.md** (comprehensive guide)  
→ Check **PROMOTION_QUICK_REFERENCE.md** (quick lookup)  
→ See **PROMOTION_UPDATE.md** (what changed)  

#### Learn LilyPond ↔ TinyNotation conversion
→ See **DUAL_FORMAT_VISUAL.txt** for side-by-side examples  
→ Check **METADATA_TINYNOTATION_FORMAT.md** for header syntax  
→ Review **first.py** for real-world examples  

#### Debug staff ordering or octave issues
→ Read **FIX_COMPLETE.md** (complete fix summary)  
→ See **DIAGNOSIS_STAFF_ISSUES.md** (technical analysis)  
→ Check **OPTIONS_STAFF_FIX.md** (solution approaches)  

#### Understand the pipeline
→ Read **RESTRUCTURE_SUMMARY.md** (pipeline flow)  
→ See **VISUAL_SUMMARY.txt** (ASCII diagrams)  
→ Check **COMPLETE_SUMMARY.md** (architecture overview)  

#### Contribute to development
→ Read **DEVELOPMENT.md** (guidelines)  
→ Check **DEVELOPER_CHANGES.md** (recent changes)  
→ See **README_DOCUMENTATION.md** (project overview)  

---

## File Organization

### Root Directory
```
first.py                    ← Two-stave composition template
second.py                   ← Additional study file
third.py                    ← Additional study file
fourth.py                   ← Additional study file
fifth.py                    ← Additional study file

project_template.py         ← Pipeline orchestrator
music_data.py               ← Data structure conversions
lilypond_parser.py          ← LilyPond → score_data parser
lily_to_tiny.py             ← LilyPond → TinyNotation converter
relative_octave_logic.py    ← Octave calculation logic

PROMOTION_WORKFLOW.md       ← Promotion guide (⭐ START HERE)
PROMOTION_QUICK_REFERENCE.md← Quick cheat sheet
FIX_COMPLETE.md             ← Staff/octave fixes summary
README_DOCUMENTATION.md     ← Project overview
```

### outputs/ Directory
```
first.py                    ← Study file copy (inspection)
first.ly                    ← Generated LilyPond source
first.pdf                   ← Musical score (PDF)
first.midi                  ← Audio playback
first.TIMESTAMP.bak         ← Backup (if promoted)

[All documentation also copied here]
```

---

## Document Status

| Document | Status | Last Updated |
|----------|--------|--------------|
| PROMOTION_WORKFLOW.md | ✅ Current | Oct 4, 2025 |
| PROMOTION_UPDATE.md | ✅ Current | Oct 4, 2025 |
| PROMOTION_VERIFICATION.md | ✅ Current | Oct 4, 2025 |
| PROMOTION_QUICK_REFERENCE.md | ✅ Current | Oct 4, 2025 |
| FIX_COMPLETE.md | ✅ Current | Oct 4, 2025 |
| DIAGNOSIS_STAFF_ISSUES.md | ✅ Current | Oct 4, 2025 |
| OPTIONS_STAFF_FIX.md | ✅ Current | Oct 4, 2025 |
| README_DOCUMENTATION.md | ✅ Current | Oct 4, 2025 |
| FIRST_PY_DOCUMENTATION.md | ✅ Current | Oct 4, 2025 |
| COMPLETE_SUMMARY.md | ✅ Current | Oct 4, 2025 |
| RESTRUCTURE_SUMMARY.md | ✅ Current | Oct 4, 2025 |
| METADATA_TINYNOTATION_FORMAT.md | ✅ Current | Oct 4, 2025 |

---

## Reading Order (Recommended)

### For New Users:
1. **README_DOCUMENTATION.md** - Start here (project overview)
2. **PROMOTION_QUICK_REFERENCE.md** - Essential commands
3. **FIRST_PY_DOCUMENTATION.md** - Template structure
4. **PROMOTION_WORKFLOW.md** - Dual-format system (when ready)

### For Developers:
1. **COMPLETE_SUMMARY.md** - Architecture overview
2. **RESTRUCTURE_SUMMARY.md** - Pipeline details
3. **DEVELOPMENT.md** - Contribution guidelines
4. **DEVELOPER_CHANGES.md** - Recent changes

### For Troubleshooting:
1. **PROMOTION_QUICK_REFERENCE.md** - Quick fixes
2. **FIX_COMPLETE.md** - Staff/octave issues
3. **PROMOTION_VERIFICATION.md** - Test matrix
4. **DIAGNOSIS_STAFF_ISSUES.md** - Deep diagnostics

---

## Version History

### v2.0 (October 4, 2025) - Dual-Format Workflow
- ✅ Both LilyPond and TinyNotation present from the start
- ✅ Toggle controls dominance (not generation)
- ✅ Improved file management (backups in outputs/)
- ✅ Enhanced documentation suite (4 new guides)

### v1.5 (October 4, 2025) - Staff Order & Octave Fixes
- ✅ Fixed staff ordering (Melody top, Harmony bottom)
- ✅ Fixed melody octave (E4 instead of E3)
- ✅ Minimal code changes (2 lines total)
- ✅ Universal benefit for all compositions

### v1.0 - Initial System
- Parser with metadata extraction
- Promotion system (original version)
- Two-stave output support
- Music21 transformations

---

## Support & Feedback

For questions or issues:
1. Check **PROMOTION_QUICK_REFERENCE.md** for quick answers
2. Review **PROMOTION_WORKFLOW.md** for detailed guidance
3. See **DIAGNOSIS_STAFF_ISSUES.md** for technical details
4. Consult **PROMOTION_VERIFICATION.md** for test results

---

## License & Attribution

**Project**: Codempose  
**Repository**: Ioanniscoder/Codempose  
**Branch**: experimental/project_template_sanitizer_fix  
**Last Updated**: October 4, 2025

---

**Quick Start**: Open `first.py`, run `python3 first.py`, check `outputs/` directory! 🎵
