# Updated Promotion System - Complete Summary

## What Changed

The promotion system has been updated to implement the **dual-format workflow** where both LilyPond and TinyNotation formats **coexist from the start** for visual correlation.

---

## Key Updates

### 1. Study Files Now Include Both Formats by Default

**Before** (old workflow):
```python
# Only LilyPond initially
SOURCE_MELODY_LILY = r"""
\relative e' { ... }
""".strip()

# TinyNotation added only after promotion
```

**After** (new workflow):
```python
# Both formats present from the start
SOURCE_MELODY_LILY = r"""
\relative e' {
    \time 6/4
    \key c \major
    \tempo 4=90
    e2 bmol4 c2 r4 |
}
""".strip()

# TinyNotation equivalent (for visual comparison with LilyPond)
# PROMOTE_TO_TINYNOTATION toggle controls which format is dominant (gets processed)
SOURCE_MELODY_TINY = "time=6/4 key=Cmajor tempo=90 e2 b-4 c'2 r4"
```

✅ **Benefit**: Immediate visual correlation between formats

---

### 2. Promotion Toggle Now Controls Dominance

**Before**: Toggle meant "generate TinyNotation"  
**After**: Toggle means "which format is dominant"

| Toggle State | Dominant Format | Behavior |
|--------------|-----------------|----------|
| `False` | LilyPond | `SOURCE_MELODY_LILY` gets processed |
| `True` | TinyNotation | `SOURCE_MELODY_TINY` gets processed |

✅ **Benefit**: Easy switching between formats for testing/experimentation

---

### 3. File Management Strategy Changed

**Before** (old workflow):
- Backup created in root directory: `first.20251004_120000.bak`
- Modified file written to root: `first.py`
- No copy to outputs

**After** (new workflow):
- **Original** backed up to outputs: `outputs/first.20251004_120000.bak`
- **Modified** written to root: `first.py` (working version)
- **Modified** copied to outputs: `outputs/first.py` (inspection copy)

✅ **Benefit**: Cleaner root directory, better organization, inspection-friendly outputs

---

## File Flow Diagram

### Normal Processing (No Promotion)

```
┌─────────────────────┐
│   first.py (root)   │
│  (both LILY + TINY) │
└──────────┬──────────┘
           │
           ├─ python3 first.py
           │
           v
┌─────────────────────────────────────┐
│         outputs/ directory          │
├─────────────────────────────────────┤
│ • first.py (copy with both formats) │
│ • first.ly (LilyPond source)        │
│ • first.pdf (musical score)         │
│ • first.midi (audio)                │
└─────────────────────────────────────┘
```

---

### With Promotion (Toggle Change)

```
STEP 1: User sets PROMOTE_TO_TINYNOTATION = True

STEP 2: Run python3 first.py

┌─────────────────────┐
│   first.py (root)   │ ──────────┐
│  ORIGINAL VERSION   │           │
└─────────────────────┘           │
                                  │ BACKUP
                                  v
                    ┌──────────────────────────────────┐
                    │  outputs/first.20251004.bak     │
                    │  (original before modification)  │
                    └──────────────────────────────────┘

           MODIFY (toggle or add TINY)
                      │
                      v
┌─────────────────────────────────────┐
│       first.py (root) MODIFIED      │
│  • Toggle changed: True ↔ False     │
│  • TinyNotation added (if missing)  │
└──────────────┬──────────────────────┘
               │
               │ COPY
               v
┌──────────────────────────────────────┐
│    outputs/first.py (MODIFIED)       │
│   (shows current state with toggle)  │
└──────────────────────────────────────┘

STEP 3: Re-run python3 first.py (processes with new dominant format)
```

---

## Updated first.py Structure

```python
"""Study file: Two-stave composition with melody and harmony snippets

PROMOTION SYSTEM:
- Both LilyPond and TinyNotation formats are present for visual correlation
- PROMOTE_TO_TINYNOTATION toggle controls which format is dominant (gets processed)
- Set to True: TinyNotation is processed
- Set to False: LilyPond is processed
"""

# ============================================================================
# PROMOTION TOGGLE
# ============================================================================

PROMOTE_TO_TINYNOTATION = False  # False = LilyPond dominant, True = TinyNotation dominant


# ============================================================================
# MELODY SNIPPETS
# ============================================================================

# Primary melody in LilyPond format (reference - visual correlation with TinyNotation)
SOURCE_MELODY_LILY = r"""
\relative e' {
    \time 6/4
    \key c \major
    \tempo 4=90
    e2 bmol4 c2 r4 |
    e2 f#4 e2 r4 |
    b2. f'2. |
    e2. c2. |
    e2 b2 c2
}
""".strip()

# TinyNotation equivalent (for visual comparison with LilyPond)
# PROMOTE_TO_TINYNOTATION toggle controls which format is dominant (gets processed)
SOURCE_MELODY_TINY = "time=6/4 key=Cmajor tempo=90 e2 b-4 c'2 r4 e'2 f#'4 e'2 r4 b'2. f''2. e''2. c''2. e''2 b''2 c'''2"

# ... rest of file ...
```

---

## Promotion Scenarios (Detailed)

### Scenario A: File Has Only LilyPond (Legacy)

**Initial state**:
```python
PROMOTE_TO_TINYNOTATION = False
SOURCE_MELODY_LILY = "..."
# No SOURCE_MELODY_TINY
```

**Action**: Set `PROMOTE_TO_TINYNOTATION = True` and run

**Result**:
1. Original → `outputs/first.TIMESTAMP.bak`
2. TinyNotation generated from LILY
3. Modified file → `first.py` (root) with both formats
4. Modified file → `outputs/first.py`
5. User prompted to re-run

**Final state**:
```python
PROMOTE_TO_TINYNOTATION = True  # TinyNotation is now dominant
SOURCE_MELODY_LILY = "..."  # Preserved
SOURCE_MELODY_TINY = "..."  # Auto-generated
```

---

### Scenario B: File Has Both Formats (Modern)

**Initial state**:
```python
PROMOTE_TO_TINYNOTATION = False  # LilyPond dominant
SOURCE_MELODY_LILY = "..."
SOURCE_MELODY_TINY = "..."
```

**Action**: Set `PROMOTE_TO_TINYNOTATION = True` and run

**Result**:
1. Original → `outputs/first.TIMESTAMP.bak`
2. Toggle switched in file
3. Modified file → `first.py` (root)
4. Modified file → `outputs/first.py`
5. User prompted to re-run

**Final state**:
```python
PROMOTE_TO_TINYNOTATION = True  # TinyNotation now dominant
SOURCE_MELODY_LILY = "..."  # Unchanged
SOURCE_MELODY_TINY = "..."  # Unchanged
```

---

### Scenario C: Manual Edit to TinyNotation

**Current state**:
```python
PROMOTE_TO_TINYNOTATION = False
SOURCE_MELODY_LILY = "..."
SOURCE_MELODY_TINY = "..."  # You edit this manually
```

**Action**: Set toggle to `True` to make your edited TINY dominant

**Result**: Next run will process your edited TinyNotation format

✅ **Benefit**: You can experiment with TinyNotation syntax directly

---

## Updated Pipeline Behavior

### Priority Order (When Using Variables)

If `build_score_data()` function is NOT present:

```
PROMOTE_TO_TINYNOTATION = False
    ↓
Uses SOURCE_MELODY_LILY

PROMOTE_TO_TINYNOTATION = True
    ↓
Uses SOURCE_MELODY_TINY
```

### With build_score_data() Function (first.py)

```python
def build_score_data():
    # Explicitly uses SOURCE_MELODY_LILY as reference
    melody_data = parse_lilypond_to_data(SOURCE_MELODY_LILY, ...)
    # Toggle doesn't affect this - function has priority
```

**Note**: When using `build_score_data()`, the function controls which format gets used internally. The toggle only affects direct variable processing (Stations 2 & 3 in the pipeline).

---

## Console Output Examples

### Normal Processing

```
============================================================
🎵 CODEMPOSE PIPELINE
============================================================
Study file: first.py
Output: outputs/first.*
============================================================

📊 Found build_score_data() function
✅ Successfully loaded via: build_score_data
   Metadata: {'title': 'First Study - Two-Part Composition', ...}
   Parts: ['Melody', 'Harmony']

🎶 Engraving 'First Study - Two-Part Composition'...
📋 Copied first.py to outputs/ (shows both LILY and TINY formats)
Wrote LilyPond file: outputs/first.ly
✅ Successfully compiled first.pdf and .midi

============================================================
✅ PIPELINE COMPLETE
============================================================
Generated files:
  • outputs/first.ly   (LilyPond source)
  • outputs/first.pdf  (Musical score)
  • outputs/first.midi (Audio playback)
============================================================
```

---

### Promotion (Toggle Change)

```
============================================================
🎵 CODEMPOSE PIPELINE
============================================================
Study file: first.py
Output: outputs/first.*
============================================================

============================================================
🔄 PROMOTION: Toggling format dominance
============================================================
Current: LilyPond is dominant
New: TinyNotation will be dominant
💾 Original copied to: outputs/first.20251004_120000.bak
✅ Modified file written to: first.py (root)
📋 Modified file copied to: outputs/first.py
============================================================

⚠️  File has been promoted. Please re-run to process the new TinyNotation format.
============================================================
```

---

## Benefits Summary

| Aspect | Old Workflow | New Workflow |
|--------|--------------|--------------|
| **Initial formats** | LILY only | LILY + TINY both |
| **Visual correlation** | ❌ Not until promotion | ✅ Immediate |
| **Toggle purpose** | Generate TINY | Control dominance |
| **Backup location** | Root directory | `outputs/` directory |
| **Inspection** | ❌ No copy in outputs | ✅ Copy in `outputs/` |
| **Root cleanliness** | ⚠️ .bak files clutter | ✅ Clean (only .py) |
| **Experimentation** | ⚠️ One format only | ✅ Switch formats easily |

---

## Migration Guide

### For Existing Study Files

If you have old study files with only `SOURCE_MELODY_LILY`:

**Option 1: Add TinyNotation Manually**
1. Convert LILY to TINY using the converter
2. Add `SOURCE_MELODY_TINY = "..."` to your file
3. Both formats now visible

**Option 2: Use Promotion Feature**
1. Set `PROMOTE_TO_TINYNOTATION = True`
2. Run the file once (auto-generates TINY)
3. Both formats now present

### For New Study Files

Use the `first.py` template pattern:
- Include both formats from the start
- Set `PROMOTE_TO_TINYNOTATION = False` by default
- Use `build_score_data()` for complex compositions

---

## Files Modified

1. **`first.py`** - Updated to include both `SOURCE_MELODY_LILY` and `SOURCE_MELODY_TINY`
2. **`project_template.py`** - Updated `promote_lilypond_to_tinynotation()` function
3. **`project_template.py`** - Updated `engrave_with_abjad()` to emphasize dual-format copy

---

## Documentation Created

1. **`PROMOTION_WORKFLOW.md`** - Complete guide to the promotion system
2. **`PROMOTION_UPDATE.md`** - This summary of changes

---

## Next Steps

1. ✅ Test promotion toggle with `first.py`
2. ✅ Verify both formats in `outputs/first.py`
3. ✅ Test toggling between formats
4. 📝 Create additional study files using the new pattern
5. 🎵 Experiment with manual TINY edits and re-promotion

---

## Conclusion

The updated promotion system provides:

✅ **Transparency**: Both formats visible for learning and comparison  
✅ **Flexibility**: Easy switching between LilyPond and TinyNotation  
✅ **Safety**: Automatic backups before any modifications  
✅ **Organization**: Clean root directory, comprehensive `outputs/`  
✅ **Workflow**: Natural progression from reference (LILY) to compact (TINY)  

The system now supports the intended **dual-format correlation** workflow while maintaining **dominance control** through the toggle mechanism.
