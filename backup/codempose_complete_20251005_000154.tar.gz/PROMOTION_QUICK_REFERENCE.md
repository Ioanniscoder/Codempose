# Promotion System - Quick Reference Card

## File Locations After Running first.py

```
Root Directory:
├── first.py ← Working version (both LILY + TINY formats)

outputs/ Directory:
├── first.py ← Inspection copy (shows both formats)
├── first.ly ← Generated LilyPond source
├── first.pdf ← Musical score (visual)
├── first.midi ← Audio playback
└── first.TIMESTAMP.bak ← Backup (only if promotion occurred)
```

---

## Toggle Behavior

```python
PROMOTE_TO_TINYNOTATION = False  # LilyPond is dominant
PROMOTE_TO_TINYNOTATION = True   # TinyNotation is dominant
```

**Note**: Only affects Stations 2 & 3 (SOURCE variables). `build_score_data()` has priority.

---

## Format Correlation Example

**LilyPond (verbose)**:
```lilypond
\relative e' {
    \time 6/4
    \key c \major
    \tempo 4=90
    e2 bmol4 c2 r4 |
}
```

**TinyNotation (compact)**:
```
time=6/4 key=Cmajor tempo=90 e2 b-4 c'2 r4
```

---

## Common Commands

### Run pipeline:
```bash
python3 first.py
```

### Check outputs:
```bash
ls -lh outputs/
cat outputs/first.py  # See both formats
```

### View PDF:
```bash
$BROWSER outputs/first.pdf
```

### Play MIDI:
```bash
# Use your preferred MIDI player
```

---

## Promotion Workflow

### 1st Run After Toggle Change:
```
📊 Found build_score_data() function

🔄 PROMOTION: Toggling format dominance
💾 Original copied to: outputs/first.TIMESTAMP.bak
✅ Modified file written to: first.py (root)
📋 Modified file copied to: outputs/first.py

⚠️  File has been promoted. Please re-run.
```

### 2nd Run (Processing):
```
📊 Found build_score_data() function
✅ Successfully loaded via: build_score_data

🎶 Engraving 'First Study - Two-Part Composition'...
📋 Copied first.py to outputs/ (shows both LILY and TINY formats)
✅ Successfully compiled first.pdf and .midi
```

---

## Pipeline Priority Order

1. **`build_score_data()`** ← Highest (used by first.py)
2. **`SOURCE_MELODY_TINY`** (if toggle = True)
3. **`SOURCE_MELODY_LILY`** (if toggle = False)
4. **`build_part()`** ← Lowest

---

## Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| Toggle changed but no effect | Run file twice (1st: promotion, 2nd: processing) |
| Can't find backup | Check `outputs/*.bak` (not root) |
| Both formats not showing | Check `outputs/first.py` copy |
| Wrong format processed | Check toggle state and pipeline priority |

---

## Documentation Index

1. **PROMOTION_WORKFLOW.md** - Complete guide (read first!)
2. **PROMOTION_UPDATE.md** - Summary of changes
3. **PROMOTION_VERIFICATION.md** - Test results
4. **PROMOTION_QUICK_REFERENCE.md** - This card

---

## One-Page Cheat Sheet

### Files
- **Root**: Working version (`first.py`)
- **outputs/**: Inspection copies + generated files

### Toggle
- `False` = LilyPond dominant
- `True` = TinyNotation dominant

### Workflow
1. Edit formats in `first.py`
2. Set toggle if switching dominant format
3. Run `python3 first.py` (twice if toggle changed)
4. Check `outputs/` for results

### Correlation
- Both formats always visible in study file
- Comment blocks explain which is dominant
- `outputs/first.py` shows current state

---

**Last Updated**: October 4, 2025  
**Version**: 2.0 (Dual-Format Workflow)
