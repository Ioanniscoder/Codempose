# music_data.py
import music21
from typing import List, Optional

def extract_data_from_part(part: music21.stream.Part, token_infos: Optional[List] = None):
    """Converts a music21.Part into a list of canonical event dictionaries.
    
    Now supports Chord objects in addition to Notes and Rests.
    Preserves articulations, dynamics, and tracking labels stored in music21 objects.
    
    Args:
        part: music21.Part to convert
        token_infos: Optional list of TokenInfo objects from parser for tracking
                     (only available when parsing LilyPond input directly)
    
    Returns:
        List of event dictionaries with tracking data if available
    """
    events = []
    for i, el in enumerate(part.flatten().notesAndRests):
        ev = {'ql': el.quarterLength}
        
        # Add tracking data from TokenInfo if available (direct parsing only)
        if token_infos and i < len(token_infos):
            token = token_infos[i]
            ev['original_token'] = token.original
            ev['position'] = token.position
            if token.warnings:
                ev['parser_warnings'] = token.warnings
        
        # Extract metadata from music21 object's .editorial namespace
        # (This is where we store articulations, dynamics, tracker during data_to_part)
        if hasattr(el, 'editorial'):
            if hasattr(el.editorial, 'articulations') and el.editorial.articulations:
                ev['articulations'] = el.editorial.articulations
            if hasattr(el.editorial, 'dynamics') and el.editorial.dynamics:
                ev['dynamics'] = el.editorial.dynamics
            if hasattr(el.editorial, 'tracker') and el.editorial.tracker:
                ev['tracker'] = el.editorial.tracker
        
        if getattr(el, 'isRest', False):
            ev['type'] = 'rest'
        elif isinstance(el, music21.chord.Chord):
            # Handle Chord objects - they have .pitches (plural), not .pitch
            ev['type'] = 'chord'
            ev['pitches'] = []
            for p in el.pitches:
                pitch_data = {
                    'step': p.step,
                    'octave': p.octave,
                    'alter': getattr(p.accidental, 'alter', 0) if p.accidental else 0
                }
                ev['pitches'].append(pitch_data)
        elif isinstance(el, music21.note.Note):
            # Handle Note objects - they have .pitch (singular)
            ev['type'] = 'note'
            ev['step'] = el.pitch.step
            ev['octave'] = el.pitch.octave
            ev['alter'] = getattr(el.pitch.accidental, 'alter', 0) if el.pitch.accidental else 0
        events.append(ev)
    return events


def _event_to_music21(ev: dict):
    """Helper function to convert a single event dictionary to a music21 element.
    
    Used by multi-voice section handling to convert voice events.
    Preserves articulations, dynamics, and tracking labels in music21.editorial namespace.
    """
    ql = ev.get('ql', 1.0)
    element = None
    
    if ev.get('type') == 'rest':
        element = music21.note.Rest(quarterLength=ql)
    
    elif ev.get('type') == 'chord':
        pitches = []
        for pitch_data in ev.get('pitches', []):
            step = pitch_data.get('step', 'c')
            octave = pitch_data.get('octave', 4)
            alter = pitch_data.get('alter', 0)
            pitch = music21.pitch.Pitch()
            pitch.step = step.upper()
            pitch.octave = octave
            if alter != 0:
                pitch.accidental = music21.pitch.Accidental(alter)
            pitches.append(pitch)
        element = music21.chord.Chord(pitches, quarterLength=ql)
    
    elif ev.get('type') == 'note':
        step = ev.get('step', 'c')
        octave = ev.get('octave', 4)
        alter = ev.get('alter', 0)
        pitch = music21.pitch.Pitch()
        pitch.step = step.upper()
        pitch.octave = octave
        if alter != 0:
            pitch.accidental = music21.pitch.Accidental(alter)
        element = music21.note.Note(pitch, quarterLength=ql)
    
    elif ev.get('type') == 'barline':
        # Barlines are typically handled at the measure level, not as individual elements
        return None
    
    # Attach metadata to element's editorial namespace if present
    if element is not None:
        if 'articulations' in ev:
            element.editorial.articulations = ev['articulations']
        if 'dynamics' in ev:
            element.editorial.dynamics = ev['dynamics']
        if 'tracker' in ev:
            element.editorial.tracker = ev['tracker']
    
    return element


def data_to_part(events: list, metadata: dict = None) -> music21.stream.Part:
    """Converts a list of canonical event dictionaries back into a music21.Part.
    
    Now supports:
    - chord and tuplet events in addition to notes and rests
    - multi_voice_section events for polyphonic staves (NEW)
    """
    part = music21.stream.Part()
    for ev in events:
        ql = ev.get('ql', 1.0)
        
        # NEW: Handle multi-voice sections (polyphonic staves)
        if ev.get('type') == 'multi_voice_section':
            voices_dict = ev.get('voices', {})
            
            # Create Voice objects for each voice
            voice_objects = []
            for voice_idx, (voice_name, voice_events) in enumerate(voices_dict.items()):
                if voice_events is None:
                    # Skip rest placeholder voices for now
                    continue
                
                voice_stream = music21.stream.Voice()
                voice_stream.id = voice_name
                
                # Add events to this voice
                for v_event in voice_events:
                    element = _event_to_music21(v_event)
                    if element:
                        voice_stream.append(element)
                
                # Set stem direction (alternating up/down)
                if voice_idx % 2 == 0:
                    # Upper voice: stems up
                    for note in voice_stream.flatten().notes:
                        note.stemDirection = 'up'
                else:
                    # Lower voice: stems down
                    for note in voice_stream.flatten().notes:
                        note.stemDirection = 'down'
                
                voice_objects.append(voice_stream)
            
            # Create measure and insert all voices at offset 0
            if voice_objects:
                measure = music21.stream.Measure()
                for voice_obj in voice_objects:
                    measure.insert(0, voice_obj)
                
                part.append(measure)
            
            continue  # Skip to next event
        
        # EXISTING: Single-event handling
        if ev.get('type') == 'rest':
            el = music21.note.Rest(quarterLength=ql)
            # Store metadata in editorial namespace for round-trip preservation
            if 'dynamics' in ev:
                el.editorial.dynamics = ev['dynamics']
            if 'tracker' in ev:
                el.editorial.tracker = ev['tracker']
            part.append(el)
        elif ev.get('type') == 'tuplet':
            # Handle tuplet events - create music21 tuplet
            numerator = ev.get('numerator', 3)
            denominator = ev.get('denominator', 2)
            tuplet_notes_data = ev.get('notes', [])
            
            # Create a tuplet group
            # music21 tuplets are created by setting tuplet properties on notes
            tuplet_notes = []
            for note_data in tuplet_notes_data:
                if note_data.get('type') == 'rest':
                    n = music21.note.Rest(quarterLength=note_data.get('ql', 1.0))
                elif note_data.get('type') == 'note':
                    step = note_data.get('step', 'c')
                    octave = note_data.get('octave', 4)
                    alter = note_data.get('alter', 0)
                    pitch = music21.pitch.Pitch()
                    pitch.step = step.upper()
                    pitch.octave = octave
                    if alter != 0:
                        pitch.accidental = music21.pitch.Accidental(alter)
                    n = music21.note.Note(pitch, quarterLength=note_data.get('ql', 1.0))
                    
                    # Add articulations to tuplet notes
                    articulations = note_data.get('articulations', [])
                    for artic in articulations:
                        if artic == 'staccato':
                            n.articulations.append(music21.articulations.Staccato())
                        elif artic == 'tenuto':
                            n.articulations.append(music21.articulations.Tenuto())
                        elif artic == 'accent':
                            n.articulations.append(music21.articulations.Accent())
                        elif artic == 'marcato':
                            n.articulations.append(music21.articulations.StrongAccent())
                        elif artic == 'staccatissimo':
                            n.articulations.append(music21.articulations.Staccatissimo())
                else:
                    continue
                tuplet_notes.append(n)
            
            # Set tuplet on all notes in the group
            if tuplet_notes:
                tup = music21.duration.Tuplet(numberNotesActual=numerator, numberNotesNormal=denominator)
                for n in tuplet_notes:
                    n.duration.appendTuplet(tup)
                    part.append(n)
                    
                    # Add dynamics after each tuplet note if present
                    if hasattr(n, 'step'):  # Only for notes, not rests
                        note_idx = tuplet_notes.index(n)
                        if note_idx < len(tuplet_notes_data):
                            dynamics = tuplet_notes_data[note_idx].get('dynamics')
                            if dynamics:
                                dyn = music21.dynamics.Dynamic(dynamics)
                                part.append(dyn)
                    
        elif ev.get('type') == 'chord':
            # Handle chord events - reconstruct Chord from pitches list
            pitches = []
            for pitch_data in ev.get('pitches', []):
                step = pitch_data.get('step', 'c')
                octave = pitch_data.get('octave', 4)
                alter = pitch_data.get('alter', 0)
                pitch = music21.pitch.Pitch()
                pitch.step = step.upper()
                pitch.octave = octave
                if alter != 0:
                    pitch.accidental = music21.pitch.Accidental(alter)
                pitches.append(pitch)
            el = music21.chord.Chord(pitches, quarterLength=ql)
            
            # Add articulations from event dictionary
            articulations = ev.get('articulations', [])
            for artic in articulations:
                if artic == 'staccato':
                    el.articulations.append(music21.articulations.Staccato())
                elif artic == 'tenuto':
                    el.articulations.append(music21.articulations.Tenuto())
                elif artic == 'accent':
                    el.articulations.append(music21.articulations.Accent())
                elif artic == 'marcato':
                    el.articulations.append(music21.articulations.StrongAccent())
                elif artic == 'staccatissimo':
                    el.articulations.append(music21.articulations.Staccatissimo())
            
            # ALSO store in editorial namespace for round-trip preservation
            if articulations:
                el.editorial.articulations = articulations
            
            # Store dynamics and tracker in editorial namespace
            if 'dynamics' in ev:
                el.editorial.dynamics = ev['dynamics']
            if 'tracker' in ev:
                el.editorial.tracker = ev['tracker']
            
            part.append(el)
            
            # Add dynamics after the chord (as a separate element in the stream)
            dynamics = ev.get('dynamics')
            if dynamics:
                dyn = music21.dynamics.Dynamic(dynamics)
                part.append(dyn)
        elif ev.get('type') == 'note':
            step = ev.get('step', 'c')
            octave = ev.get('octave', 4)
            alter = ev.get('alter', 0)
            pitch = music21.pitch.Pitch()
            pitch.step = step.upper()
            pitch.octave = octave
            if alter != 0:
                pitch.accidental = music21.pitch.Accidental(alter)
            el = music21.note.Note(pitch, quarterLength=ql)
            
            # Add articulations from event dictionary
            articulations = ev.get('articulations', [])
            for artic in articulations:
                if artic == 'staccato':
                    el.articulations.append(music21.articulations.Staccato())
                elif artic == 'tenuto':
                    el.articulations.append(music21.articulations.Tenuto())
                elif artic == 'accent':
                    el.articulations.append(music21.articulations.Accent())
                elif artic == 'marcato':
                    el.articulations.append(music21.articulations.StrongAccent())
                elif artic == 'staccatissimo':
                    el.articulations.append(music21.articulations.Staccatissimo())
            
            # ALSO store in editorial namespace for round-trip preservation
            if articulations:
                el.editorial.articulations = articulations
            
            # Store dynamics and tracker in editorial namespace
            if 'dynamics' in ev:
                el.editorial.dynamics = ev['dynamics']
            if 'tracker' in ev:
                el.editorial.tracker = ev['tracker']
            
            part.append(el)
            
            # Add dynamics after the note (as a separate element in the stream)
            dynamics = ev.get('dynamics')
            if dynamics:
                dyn = music21.dynamics.Dynamic(dynamics)
                part.append(dyn)
        else:
            continue
    return part


def build_lilypond_file(score_data: dict, output_basename: str, source_file: str = None):
    """
    Build and write LilyPond file with documentation.
    
    This is a wrapper around engrave_with_abjad() for backward compatibility
    with tenth.py's expected interface.
    
    Args:
        score_data: Complete score data dictionary
        output_basename: Base name for output file (e.g., 'tenth')
        source_file: Optional path to source Python file for attribution
    """
    from project_template import engrave_with_abjad
    from pathlib import Path
    
    # Extract basename without extension
    basename = Path(output_basename).stem
    
    # Delegate to existing function
    engrave_with_abjad(score_data, basename, source_file=source_file)


def part_to_data(part: music21.stream.Part) -> list:
    """
    Convert a music21.stream.Part back to canonical event format.
    
    This is the inverse of data_to_part(). It extracts notes, rests, chords,
    and other musical elements from a music21 Part and converts them to the
    canonical event dictionary format used by Codempose.
    
    Args:
        part: music21.stream.Part to convert
        
    Returns:
        list: Canonical event dictionaries
        
    Example:
        >>> part = music21.stream.Part()
        >>> part.append(music21.note.Note('C4', quarterLength=1.0))
        >>> events = part_to_data(part)
        >>> events[0]
        {'type': 'note', 'step': 'C', 'octave': 4, 'alter': 0, 'ql': 1.0}
    """
    events = []
    
    # Flatten the part to get all elements in sequence
    for element in part.flatten():
        if isinstance(element, music21.note.Note):
            # Convert Note to canonical format
            event = {
                'type': 'note',
                'step': element.pitch.step,
                'octave': element.pitch.octave,
                'alter': element.pitch.alter if element.pitch.alter else 0,
                'ql': element.quarterLength
            }
            
            # Add articulations if present
            if element.articulations:
                artic_names = []
                for artic in element.articulations:
                    artic_name = artic.name.lower()
                    if 'staccato' in artic_name:
                        artic_names.append('staccato')
                    elif 'tenuto' in artic_name:
                        artic_names.append('tenuto')
                    elif 'accent' in artic_name:
                        artic_names.append('accent')
                    elif 'marcato' in artic_name or 'strong' in artic_name:
                        artic_names.append('marcato')
                if artic_names:
                    event['articulations'] = artic_names
            
            # Add dynamics if present
            if hasattr(element, 'volume') and element.volume.velocity:
                if element.volume.velocity < 50:
                    event['dynamic'] = 'p'
                elif element.volume.velocity < 80:
                    event['dynamic'] = 'mf'
                else:
                    event['dynamic'] = 'f'
            
            events.append(event)
            
        elif isinstance(element, music21.note.Rest):
            # Convert Rest to canonical format
            events.append({
                'type': 'rest',
                'ql': element.quarterLength
            })
            
        elif isinstance(element, music21.chord.Chord):
            # Convert Chord to canonical format
            pitches = []
            for pitch in element.pitches:
                pitches.append({
                    'step': pitch.step,
                    'octave': pitch.octave,
                    'alter': pitch.alter if pitch.alter else 0
                })
            
            event = {
                'type': 'chord',
                'pitches': pitches,
                'ql': element.quarterLength
            }
            
            # Add articulations if present
            if element.articulations:
                artic_names = []
                for artic in element.articulations:
                    artic_name = artic.name.lower()
                    if 'staccato' in artic_name:
                        artic_names.append('staccato')
                    elif 'tenuto' in artic_name:
                        artic_names.append('tenuto')
                    elif 'accent' in artic_name:
                        artic_names.append('accent')
                if artic_names:
                    event['articulations'] = artic_names
            
            events.append(event)
    
    return events
