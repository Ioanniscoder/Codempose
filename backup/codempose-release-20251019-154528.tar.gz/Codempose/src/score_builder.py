"""
Score Builder: Blueprint String Framework
==========================================

Composer-centric shorthand for assembling multi-stave scores using
blueprint strings with intuitive delimiters.

NEW: Supports on-the-fly transformations in blueprint strings!

TRANSFORMATION SYNTAX (HYBRID MODEL):
-------------------------------------

1. NO SUFFIX (for single-part transformations):
   transpose_part(THEME, 'P5')
   → Returns single part, auto-caches with .id = 'melody'
   → Backward compatible with existing studies

2. SUFFIX (for multi-part transformations):
   harmonize_part(MELODY, 'I-IV-V-I'):melody
   harmonize_part(MELODY, 'I-IV-V-I'):harmony
   → Runs once, caches all named parts
   → Second call is a simple lookup

3. ERROR HANDLING:
   harmonize_part(MELODY, 'I-IV-V-I')  [no suffix]
   → ERROR: "Multi-part transformation requires suffix"
   → Prevents ambiguity

Example:
    VOICE_STAVE_DEF = "Melody & Bass"
    
    VOICE_STAVE_DATA = '''
        transpose_part(THEME, 'P5') & BASS;
        harmonize_part(MELODY, 'I-V-I'):melody & harmonize_part(MELODY, 'I-V-I'):harmony
    '''
"""

from typing import Dict, List, Any, Optional
import re
import music21

# Import transformation functions and data conversion utilities
from src import transformations
from src.music_data import data_to_part, extract_data_from_part, part_to_data


# ============================================================================
# TRANSFORMATION CACHE (Cleared at start of each build)
# ============================================================================

# Global cache to track which transformations have been run and what parts they produced.
# This enables the "run once, cache all parts" behavior for multi-part transformations.
# Cleared at the start of build_score_from_blueprint() to prevent pollution between builds.
_TRANSFORMATION_CACHE_STATUS = {}


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def normalize_blueprint_string(data_string: str) -> str:
    """Clean blueprint string by removing comments and whitespace."""
    lines = []
    for line in data_string.split('\n'):
        line = re.sub(r'#.*$', '', line)
        line = line.strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)


def _get_or_create_snippet_events(snippet_name: str, snippets: Dict[str, List[Dict]]) -> List[Dict]:
    """
    Get events from snippets dict, applying transformations on-the-fly if needed.
    
    HYBRID MODEL LOGIC:
    -------------------
    
    1. NO SUFFIX (e.g., 'transpose_part(THEME, 'P5')'):
       - Runs transformation
       - If returns single Part: auto-caches and returns events (backward compatible)
       - If returns Score: ERROR (composer must specify which part with suffix)
    
    2. WITH SUFFIX (e.g., 'harmonize_part(THEME):harmony'):
       - Runs base transformation ONCE
       - Caches ALL named parts (e.g., :melody, :harmony)
       - Returns only the requested part's events
       - Subsequent calls with same base are lookups (no re-execution)
    
    3. AUTO-ID ASSIGNMENT:
       - Single Parts without .id get auto-assigned .id = 'melody'
       - Removes developer burden for simple transformations
    
    Args:
        snippet_name: Either simple name, transformation call, or suffixed transformation
        snippets: Dictionary of snippet_name -> event_list
    
    Returns:
        List of event dictionaries
    
    Examples:
        # Simple snippet lookup
        >>> _get_or_create_snippet_events('THEME', snippets)
        
        # Single-part transformation (no suffix needed)
        >>> _get_or_create_snippet_events("transpose_part(THEME, 'P5')", snippets)
        
        # Multi-part transformation (suffix required)
        >>> _get_or_create_snippet_events("harmonize_part(THEME, 'I-V-I'):melody", snippets)
        >>> _get_or_create_snippet_events("harmonize_part(THEME, 'I-V-I'):harmony", snippets)
    """
    # 1. Check if snippet (or its result) is already in the dictionary
    if snippet_name in snippets:
        return snippets[snippet_name]
    
    # 2. Check for SUFFIXED transformation syntax: base_instruction:part_id
    #    e.g., "harmonize_part(THEME, 'I-V-I'):harmony"
    suffix_match = re.match(r'^(.*\)):(\w+)$', snippet_name)
    
    if suffix_match:
        # This is a SUFFIXED transformation
        base_instruction = suffix_match.group(1)  # e.g., "harmonize_part(THEME, 'I-V-I')"
        requested_part_id = suffix_match.group(2)  # e.g., "harmony"
        
        # Check if this base transformation has already been run
        if base_instruction in _TRANSFORMATION_CACHE_STATUS:
            # Already ran - this is a lookup
            if snippet_name not in snippets:
                available_parts = _TRANSFORMATION_CACHE_STATUS[base_instruction]
                raise KeyError(
                    f"❌ Transformation '{base_instruction}' was executed, but did not provide "
                    f"a part named '{requested_part_id}'.\n"
                    f"   Available parts: {available_parts}\n"
                    f"   Did you mean: {', '.join(f':{p}' for p in available_parts)}?"
                )
            return snippets[snippet_name]
        
        # First call with this base - run the transformation
        return _run_and_cache_transformation(base_instruction, requested_part_id, snippet_name, snippets)
    
    # 3. Check for REPEAT syntax: SNIPPET * N
    import copy
    repeat_match = re.match(r'^\s*(.+?)\s*\*\s*(\d+)\s*$', snippet_name)
    if repeat_match:
        base_snippet = repeat_match.group(1).strip()
        repeat_count = int(repeat_match.group(2))
        
        # Recursively get base events (handles nested transformations)
        base_events = _get_or_create_snippet_events(base_snippet, snippets)
        
        # Repeat the events
        repeated_events = []
        for _ in range(repeat_count):
            repeated_events.extend(copy.deepcopy(base_events))
        
        # Cache the result
        snippets[snippet_name] = repeated_events
        print(f"      ✓ Repeated {base_snippet} × {repeat_count} = {len(repeated_events)} events")
        
        return repeated_events
    
    # 4. Check for UNSUFFIXED transformation syntax: func_name(base_snippet, arg1, ...)
    transform_match = re.match(r'^\s*(\w+)\s*\((.*)\)\s*$', snippet_name)
    if transform_match:
        # This is an UNSUFFIXED transformation
        # It will work for single-part returns, error for multi-part returns
        return _run_and_cache_transformation(snippet_name, None, snippet_name, snippets)
    
    # 5. Not found and not a transformation
    raise KeyError(
        f"❌ Snippet '{snippet_name}' not found and is not a valid transformation.\n"
        f"   Available snippets: {list(snippets.keys())}\n"
        f"   Transformation syntax: function_name(snippet, 'arg') or function_name(snippet, 'arg'):part_id"
    )


def _run_and_cache_transformation(
    base_instruction: str,
    requested_part_id: Optional[str],
    cache_key: str,
    snippets: Dict[str, List[Dict]]
) -> List[Dict]:
    """
    Execute a transformation function and cache its results.
    
    HYBRID BEHAVIOR:
    ----------------
    - If requested_part_id is None (unsuffixed call):
      * Single Part return: auto-cache with .id='melody', return events
      * Score return: ERROR (composer must use suffix)
    
    - If requested_part_id is provided (suffixed call):
      * Cache all parts with their IDs as suffixes
      * Return only the requested part
    
    Args:
        base_instruction: The transformation call (e.g., "harmonize_part(THEME, 'I-V-I')")
        requested_part_id: The part ID from suffix (e.g., "harmony"), or None if unsuffixed
        cache_key: The full key to use for caching (includes suffix if present)
        snippets: The snippets dictionary to update
    
    Returns:
        List of event dictionaries for the requested/primary part
    """
    print(f"      🔄 Applying transformation: {base_instruction}")
    
    # Parse the transformation call
    match = re.match(r'^\s*(\w+)\s*\((.*)\)\s*$', base_instruction)
    if not match:
        raise ValueError(f"❌ Invalid transformation syntax: {base_instruction}")
    
    func_name = match.group(1)
    args_str = match.group(2)
    
    # Parse arguments
    parsed_args = []
    if args_str:
        for arg in args_str.split(','):
            arg = arg.strip()
            # String literal (quoted)
            if (arg.startswith("'") and arg.endswith("'")) or \
               (arg.startswith('"') and arg.endswith('"')):
                parsed_args.append(arg[1:-1])  # Remove quotes
            # Float (has decimal point)
            elif '.' in arg:
                try:
                    parsed_args.append(float(arg))
                except ValueError:
                    parsed_args.append(arg)  # Treat as snippet name
            # Integer
            else:
                try:
                    parsed_args.append(int(arg))
                except ValueError:
                    parsed_args.append(arg)  # Treat as snippet name
    
    if not parsed_args:
        raise ValueError(f"❌ Transformation '{func_name}' has no arguments.")
    
    # Get base snippet events (first argument) - recursively handle transformations
    base_snippet_name = parsed_args.pop(0)
    base_events = _get_or_create_snippet_events(base_snippet_name, snippets)
    base_part = data_to_part(base_events, {})
    
    # Get and call the transformation function
    try:
        transform_func = getattr(transformations, func_name)
    except AttributeError:
        raise ValueError(
            f"❌ Transformation function '{func_name}' not found in transformations.py.\n"
            f"   Available: identity, transpose_part, invert_part, retrograde_part, "
            f"augment_part, diminish_part, chordify_part, retrograde_inversion, "
            f"transpose_and_augment, harmonize_part, analyze_structural_tones"
        )
    
    transformed_result = transform_func(base_part, *parsed_args)
    
    # HYBRID LOGIC: Handle based on return type and suffix presence
    
    if isinstance(transformed_result, music21.stream.Part):
        # SINGLE PART RETURN
        
        # Auto-assign .id if missing
        if not transformed_result.id:
            transformed_result.id = 'melody'
            print(f"      ℹ️  Auto-assigned .id = 'melody' to single-part result")
        
        part_events = part_to_data(transformed_result)
        
        if requested_part_id is None:
            # UNSUFFIXED CALL - This is the backward-compatible case
            snippets[cache_key] = part_events
            _TRANSFORMATION_CACHE_STATUS[base_instruction] = [transformed_result.id]
            print(f"      ✓ Single Part returned, cached as '{cache_key}'")
            return part_events
        else:
            # SUFFIXED CALL - Verify requested ID matches
            if requested_part_id != transformed_result.id:
                raise KeyError(
                    f"❌ Transformation '{base_instruction}' returned a single part with "
                    f".id = '{transformed_result.id}', but you requested ':{ requested_part_id}'.\n"
                    f"   Use ':{transformed_result.id}' instead, or call without suffix."
                )
            
            # Cache with suffix
            full_key = f"{base_instruction}:{transformed_result.id}"
            snippets[full_key] = part_events
            _TRANSFORMATION_CACHE_STATUS[base_instruction] = [transformed_result.id]
            print(f"      ✓ Single Part returned, cached as '{full_key}'")
            return part_events
    
    elif isinstance(transformed_result, music21.stream.Score):
        # MULTI-PART RETURN (Score)
        
        if requested_part_id is None:
            # UNSUFFIXED CALL - This is an ERROR for multi-part returns
            raise ValueError(
                f"❌ Transformation '{base_instruction}' returns multiple parts.\n"
                f"   You MUST specify which part you want using a suffix.\n"
                f"   Example: {base_instruction}:melody  or  {base_instruction}:harmony\n"
                f"   \n"
                f"   This transformation returned {len(transformed_result.parts)} parts.\n"
                f"   Run it once to see what part IDs are available."
            )
        
        # SUFFIXED CALL - Cache all parts and return requested one
        print(f"      → Detected Score with {len(transformed_result.parts)} parts. Caching all:")
        
        cached_part_ids = []
        for part in transformed_result.parts:
            if not part.id:
                raise ValueError(
                    f"❌ Transformation '{func_name}' returned a Score, but one of its "
                    f"parts is missing a .id attribute.\n"
                    f"   The transformation function must set .id on all returned parts.\n"
                    f"   Example: melody_part.id = 'melody'; bass_part.id = 'harmony'"
                )
            
            part_events = part_to_data(part)
            full_key = f"{base_instruction}:{part.id}"
            snippets[full_key] = part_events
            cached_part_ids.append(part.id)
            print(f"         ... Cached as '{full_key}'")
        
        _TRANSFORMATION_CACHE_STATUS[base_instruction] = cached_part_ids
        
        # Return the requested part
        requested_key = f"{base_instruction}:{requested_part_id}"
        if requested_key not in snippets:
            raise KeyError(
                f"❌ Transformation '{base_instruction}' ran successfully, but did not "
                f"provide a part named '{requested_part_id}'.\n"
                f"   Available parts: {cached_part_ids}\n"
                f"   Did you mean: {', '.join(f':{p}' for p in cached_part_ids)}?"
            )
        
        return snippets[requested_key]
    
    else:
        raise TypeError(
            f"❌ Transformation '{func_name}' returned unexpected type: {type(transformed_result)}.\n"
            f"   Must return music21.stream.Part or music21.stream.Score."
        )


# ============================================================================
# BLUEPRINT STRING PARSING
# ============================================================================

def parse_voice_stave_def(def_string: str) -> List[List[str]]:
    """
    Parse VOICE_STAVE_DEF header into layout structure.
    
    Examples:
        "UpperStaff & LowerStaff" -> [['UpperStaff'], ['LowerStaff']]
        "(Soprano, Alto) & (Tenor, Bass)" -> [['Soprano', 'Alto'], ['Tenor, Bass']]
    """
    def_string = def_string.strip()
    staff_defs = [s.strip() for s in def_string.split('&')]
    
    layout = []
    for staff_def in staff_defs:
        if staff_def.startswith('(') and staff_def.endswith(')'):
            voices_str = staff_def[1:-1]
            voices = [v.strip() for v in voices_str.split(',')]
            layout.append(voices)
        else:
            layout.append([staff_def])
    
    return layout


def parse_voice_stave_data(data_string: str, layout: List[List[str]]) -> List[List[List[str]]]:
    """
    Parse VOICE_STAVE_DATA body into section/staff/snippet structure.
    
    Delimiter hierarchy:
      1. ; splits sections (rows)
      2. & splits staves (columns)
      3. | concatenates snippets (cells)
      4. , separates voices in multi-voice staves
    """
    cleaned = normalize_blueprint_string(data_string)
    section_strings = [s.strip() for s in cleaned.split(';') if s.strip()]
    
    sections = []
    for section_idx, section_str in enumerate(section_strings):
        staff_strings = [s.strip() for s in section_str.split('&')]
        
        if len(staff_strings) != len(layout):
            raise ValueError(
                f"Section {section_idx + 1} has {len(staff_strings)} staves "
                f"but layout defines {len(layout)} staves"
            )
        
        section = []
        for staff_idx, staff_str in enumerate(staff_strings):
            voice_names = layout[staff_idx]
            
            if len(voice_names) > 1:
                voice_strings = [v.strip() for v in staff_str.split(',')]
                
                if len(voice_strings) != len(voice_names):
                    raise ValueError(
                        f"Section {section_idx + 1}, Staff {staff_idx + 1} "
                        f"has {len(voice_names)} voices but provides {len(voice_strings)}"
                    )
                
                staff_content = []
                for voice_str in voice_strings:
                    snippets_list = [s.strip() for s in voice_str.split('|') if s.strip()]
                    staff_content.append(snippets_list)
                section.append(staff_content)
            else:
                snippets_list = [s.strip() for s in staff_str.split('|') if s.strip()]
                section.append(snippets_list)
        
        sections.append(section)
    
    return sections


def build_score_from_blueprint(
    voice_stave_def: str,
    voice_stave_data: str,
    snippets: Dict[str, List[Dict]],
    metadata: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Build complete score data from blueprint strings.
    
    This function clears the transformation cache at the start to ensure
    each build is isolated and prevent state pollution between runs.
    """
    # Clear transformation cache (prevents pollution between builds)
    global _TRANSFORMATION_CACHE_STATUS
    _TRANSFORMATION_CACHE_STATUS.clear()
    
    print("\n" + "="*70)
    print("BLUEPRINT STRING FRAMEWORK")
    print("="*70)
    
    print("\n[Parsing layout definition...]")
    layout = parse_voice_stave_def(voice_stave_def)
    
    print(f"✓ Layout structure: {len(layout)} staves")
    for idx, voices in enumerate(layout):
        if len(voices) == 1:
            print(f"   Staff {idx + 1}: {voices[0]} (single voice)")
        else:
            print(f"   Staff {idx + 1}: {', '.join(voices)} ({len(voices)} voices)")
    
    print("\n[Parsing content definition...]")
    sections = parse_voice_stave_data(voice_stave_data, layout)
    
    print(f"✓ Content structure: {len(sections)} sections")
    for section_idx, section in enumerate(sections):
        print(f"   Section {section_idx + 1}:")
        for staff_idx, staff_content in enumerate(section):
            staff_name = layout[staff_idx][0] if len(layout[staff_idx]) == 1 else f"({', '.join(layout[staff_idx])})"
            
            if isinstance(staff_content[0], list):
                for voice_idx, voice_snippets in enumerate(staff_content):
                    voice_name = layout[staff_idx][voice_idx]
                    snippet_str = ' | '.join(voice_snippets)
                    print(f"      {voice_name}: {snippet_str}")
            else:
                snippet_str = ' | '.join(staff_content)
                print(f"      {staff_name}: {snippet_str}")
    
    print("\n[Assembling events from snippets...]")
    
    parts = {}
    for staff_idx, voices in enumerate(layout):
        staff_name = voices[0] if len(voices) == 1 else f"Staff{staff_idx + 1}"
        parts[staff_name] = []
    
    for section_idx, section in enumerate(sections):
        print(f"\n   Section {section_idx + 1}:")
        
        section_durations = {}
        
        for staff_idx, staff_content in enumerate(section):
            staff_name = list(parts.keys())[staff_idx]
            
            # Check if this is a multi-voice staff
            if staff_content and isinstance(staff_content[0], list):
                # Multi-voice staff: staff_content is list of voice snippet lists
                voice_names = layout[staff_idx]
                
                if len(voice_names) > 1:
                    # Process ALL voices in multi-voice staff
                    voice_events_dict = {}
                    total_ql = 0
                    
                    for voice_idx, voice_snippets in enumerate(staff_content):
                        voice_name = voice_names[voice_idx]
                        
                        # Handle rest placeholder
                        if voice_snippets == ['r']:
                            voice_events_dict[voice_name] = None  # Will fill with rests later
                            print(f"      {voice_name}: (rest - duration TBD)")
                            continue
                        
                        # Collect events for this voice
                        voice_events = []
                        for snippet_name in voice_snippets:
                            # Use helper function to support on-the-fly transformations
                            snippet_events = _get_or_create_snippet_events(snippet_name, snippets)
                            
                            voice_events.extend(snippet_events)
                            print(f"      {voice_name}: +{snippet_name} ({len(snippet_events)} events)")
                        
                        voice_events_dict[voice_name] = voice_events
                        
                        # Calculate duration for this voice
                        voice_ql = sum(e.get('ql', 0) for e in voice_events if e.get('type') != 'barline')
                        if voice_ql > total_ql:
                            total_ql = voice_ql
                    
                    # Create multi-voice section event
                    parts[staff_name].append({
                        'type': 'multi_voice_section',
                        'voices': voice_events_dict
                    })
                    
                    section_durations[staff_name] = total_ql
                else:
                    # Single voice in parentheses (treat as simple single-voice)
                    snippet_names = staff_content[0]
                    
                    if snippet_names == ['r']:
                        section_durations[staff_name] = None
                        print(f"      {staff_name}: (rest - duration TBD)")
                        continue
                    
                    staff_events = []
                    for snippet_name in snippet_names:
                        # Use helper function to support on-the-fly transformations
                        snippet_events = _get_or_create_snippet_events(snippet_name, snippets)
                        
                        # Hybrid model always returns List[Dict] (events), never dict of parts
                        staff_events.extend(snippet_events)
                        print(f"      {staff_name}: +{snippet_name} ({len(snippet_events)} events)")
                    
                    total_ql = sum(e.get('ql', 0) for e in staff_events if e.get('type') != 'barline')
                    section_durations[staff_name] = total_ql
                    
                    parts[staff_name].extend(staff_events)
            else:
                # Single-voice staff (simple list)
                snippet_names = staff_content
                
                if snippet_names == ['r']:
                    section_durations[staff_name] = None
                    print(f"      {staff_name}: (rest - duration TBD)")
                    continue
                
                staff_events = []
                for snippet_name in snippet_names:
                    # Use helper function to support on-the-fly transformations
                    snippet_events = _get_or_create_snippet_events(snippet_name, snippets)
                    
                    # Hybrid model always returns List[Dict] (events), never dict of parts
                    staff_events.extend(snippet_events)
                    print(f"      {staff_name}: +{snippet_name} ({len(snippet_events)} events)")
                
                total_ql = sum(e.get('ql', 0) for e in staff_events if e.get('type') != 'barline')
                section_durations[staff_name] = total_ql
                
                parts[staff_name].extend(staff_events)
        
        active_durations = [d for d in section_durations.values() if d is not None]
        if active_durations:
            max_duration = max(active_durations)
            
            if len(set(active_durations)) > 1:
                print(f"\n   ⚠️  WARNING: Section {section_idx + 1} has mismatched durations")
                for staff_name, duration in section_durations.items():
                    if duration is not None:
                        print(f"      {staff_name}: {duration} QL")
            
            for staff_name, duration in section_durations.items():
                if duration is None:
                    bar_duration = 4.0
                    num_bars = int(max_duration / bar_duration)
                    
                    rest_events = []
                    for _ in range(num_bars):
                        rest_events.append({'type': 'rest', 'ql': bar_duration})
                    
                    parts[staff_name].extend(rest_events)
                    print(f"      {staff_name}: Generated {num_bars} bar rests ({max_duration} QL)")
        
        for staff_name in parts.keys():
            parts[staff_name].append({'type': 'barline', 'style': '||', 'ql': 0.0})
    
    print("\n" + "="*70)
    print("BLUEPRINT ASSEMBLY COMPLETE")
    print("="*70)
    
    for staff_name, events in parts.items():
        total_ql = sum(e.get('ql', 0) for e in events if e.get('type') != 'barline')
        print(f"✓ {staff_name}: {len(events)} events ({total_ql} QL)")
    
    return {
        'metadata': metadata,
        'parts': parts
    }
