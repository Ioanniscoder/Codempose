# Codempose - Compositional Music Framework

**A Python-based music composition framework with LilyPond engraving, MIDI export, and MusicXML generation.**

---

## 🎵 Quick Start

### 1. Generate a New Study
```bash
python generate_study.py 2 "My Composition"
```

This creates `studies/second.py` with a complete Blueprint Strings template.

### 2. Edit Your Composition
Open `studies/second.py` and edit the musical snippets:
```python
SNIPPETS = {
    'INTRO': r"\relative c' { c4 d e f }",
    'THEME': r"\relative c' { g4 a b c }",
}
```

### 3. Run the Pipeline
```bash
python studies/second.py
```

This generates in `outputs/`:
- `second.ly` - LilyPond source
- `second.pdf` - Engraved score
- `second.midi` - Audio playback
- `second.musicxml` - MuseScore import

---

## 📂 Project Structure

```
Codempose/
├── generate_study.py              # Generate new study files
├── CODEMPOSE_STUDY_TEMPLATES.py   # Template library
│
├── src/                           # Core modules
│   ├── project_template.py        # Main pipeline
│   ├── score_builder.py           # Blueprint Strings engine
│   ├── lilypond_parser.py         # Parser
│   └── ...                        # Other modules
│
├── studies/                       # Your compositions
│   ├── _study_path.py             # Auto-import helper
│   └── OLD/                       # Archived studies
│
├── outputs/                       # Generated files (browser root)
│   ├── TEMPLATES/                 # Reference examples
│   └── DOCUMENTATION/             # Generated docs
│
├── tests/                         # Test suite (11 tests, 100% passing)
└── DOCUMENTATION/                 # Project documentation
```

---

## 🎼 Blueprint Strings Framework (Recommended)

The **composer-first** approach using musical delimiters:

### Delimiters
- `;` (semicolon) - Section separator
- `&` (ampersand) - Staff separator (vertical stacking)
- `|` (pipe) - Concatenation (horizontal "then")
- `,` (comma) - Voice separator (polyphonic staves)
- `'r'` - Auto-rest placeholder

### Example
```python
VOICE_STAVE_DEF = "Melody & Bass"
VOICE_STAVE_DATA = "INTRO ; THEME_A, HARMONY & BASS"
```

**Result**: 2 staves, 2 sections
- Section 1: Melody plays INTRO, Bass rests
- Section 2: Melody plays THEME_A + HARMONY (polyphonic), Bass plays BASS

See generated study files for all 7 layout variants!

---

## 🔧 Running from Different Locations

Studies work from anywhere thanks to absolute paths:
```bash
# From root
python studies/second.py

# From studies/
cd studies && python second.py

# From anywhere
python /path/to/studies/second.py
```

All outputs always go to `/workspaces/Codempose/outputs/`

---

## 📚 Documentation

- `DOCUMENTATION/` - Migration reports, analysis docs
- `outputs/TEMPLATES/` - Music21 API examples, tonal harmony templates
- `outputs/DOCUMENTATION/` - Generated documentation
- Generated studies - Inline comments with all examples

---

## ✅ Test Suite

```bash
python -m pytest tests/ -v
```

**Status**: 11 tests, 100% passing  
**Coverage**: Chord parsing, pipeline, MIDI generation, hybrid enharmonic handling

---

## 🎯 Features

- **Blueprint Strings** - Intuitive composition with musical delimiters
- **LilyPond Engraving** - Professional score layout via Abjad
- **Multi-format Export** - PDF, MIDI, MusicXML, LilyPond
- **Hybrid Verification** - Intelligent pitch spelling validation
- **Harmonic Analysis** - Structural tone detection
- **Composition Shortcuts** - Transpose, invert, retrograde operations
- **Absolute Paths** - Works from any directory, browser integration ready

---

## 📖 Example Workflow

```bash
# 1. Generate new study
python generate_study.py 5 "SATB Chorale"

# 2. Edit studies/fifth.py - add your music

# 3. Run pipeline
python studies/fifth.py

# 4. View outputs/fifth.pdf in browser
# (outputs/ directory is the browser root)

# 5. Import outputs/fifth.musicxml to MuseScore for further editing
```

---

## 🛠️ Requirements

- Python 3.11+
- Abjad (LilyPond wrapper)
- music21
- LilyPond (for PDF generation)

See `requirements.txt` or `.devcontainer/` for full setup.

---

**Version**: October 2025  
**Structure**: Clean migration - src/ organized, 100% tests passing, Blueprint Strings as default
