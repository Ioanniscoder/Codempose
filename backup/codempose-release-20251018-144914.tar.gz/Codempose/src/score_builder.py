"""
Score Builder: Blueprint String Framework
==========================================

Composer-centric shorthand for assembling multi-stave scores using
blueprint strings with intuitive delimiters.
"""

from typing import Dict, List, Any
import re


def normalize_blueprint_string(data_string: str) -> str:
    """Clean blueprint string by removing comments and whitespace."""
    lines = []
    for line in data_string.split('\n'):
        line = re.sub(r'#.*$', '', line)
        line = line.strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)


def parse_voice_stave_def(def_string: str) -> List[List[str]]:
    """
    Parse VOICE_STAVE_DEF header into layout structure.
    
    Examples:
        "UpperStaff & LowerStaff" -> [['UpperStaff'], ['LowerStaff']]
        "(Soprano, Alto) & (Tenor, Bass)" -> [['Soprano', 'Alto'], ['Tenor', 'Bass']]
    """
    def_string = def_string.strip()
    staff_defs = [s.strip() for s in def_string.split('&')]
    
    layout = []
    for staff_def in staff_defs:
        if staff_def.startswith('(') and staff_def.endswith(')'):
            voices_str = staff_def[1:-1]
            voices = [v.strip() for v in voices_str.split(',')]
            layout.append(voices)
        else:
            layout.append([staff_def])
    
    return layout


def parse_voice_stave_data(data_string: str, layout: List[List[str]]) -> List[List[List[str]]]:
    """
    Parse VOICE_STAVE_DATA body into section/staff/snippet structure.
    
    Delimiter hierarchy:
      1. ; splits sections (rows)
      2. & splits staves (columns)
      3. | concatenates snippets (cells)
      4. , separates voices in multi-voice staves
    """
    cleaned = normalize_blueprint_string(data_string)
    section_strings = [s.strip() for s in cleaned.split(';') if s.strip()]
    
    sections = []
    for section_idx, section_str in enumerate(section_strings):
        staff_strings = [s.strip() for s in section_str.split('&')]
        
        if len(staff_strings) != len(layout):
            raise ValueError(
                f"Section {section_idx + 1} has {len(staff_strings)} staves "
                f"but layout defines {len(layout)} staves"
            )
        
        section = []
        for staff_idx, staff_str in enumerate(staff_strings):
            voice_names = layout[staff_idx]
            
            if len(voice_names) > 1:
                voice_strings = [v.strip() for v in staff_str.split(',')]
                
                if len(voice_strings) != len(voice_names):
                    raise ValueError(
                        f"Section {section_idx + 1}, Staff {staff_idx + 1} "
                        f"has {len(voice_names)} voices but provides {len(voice_strings)}"
                    )
                
                staff_content = []
                for voice_str in voice_strings:
                    snippets_list = [s.strip() for s in voice_str.split('|') if s.strip()]
                    staff_content.append(snippets_list)
                section.append(staff_content)
            else:
                snippets_list = [s.strip() for s in staff_str.split('|') if s.strip()]
                section.append(snippets_list)
        
        sections.append(section)
    
    return sections


def build_score_from_blueprint(
    voice_stave_def: str,
    voice_stave_data: str,
    snippets: Dict[str, List[Dict]],
    metadata: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Build complete score data from blueprint strings.
    """
    print("\n" + "="*70)
    print("BLUEPRINT STRING FRAMEWORK")
    print("="*70)
    
    print("\n[Parsing layout definition...]")
    layout = parse_voice_stave_def(voice_stave_def)
    
    print(f"✓ Layout structure: {len(layout)} staves")
    for idx, voices in enumerate(layout):
        if len(voices) == 1:
            print(f"   Staff {idx + 1}: {voices[0]} (single voice)")
        else:
            print(f"   Staff {idx + 1}: {', '.join(voices)} ({len(voices)} voices)")
    
    print("\n[Parsing content definition...]")
    sections = parse_voice_stave_data(voice_stave_data, layout)
    
    print(f"✓ Content structure: {len(sections)} sections")
    for section_idx, section in enumerate(sections):
        print(f"   Section {section_idx + 1}:")
        for staff_idx, staff_content in enumerate(section):
            staff_name = layout[staff_idx][0] if len(layout[staff_idx]) == 1 else f"({', '.join(layout[staff_idx])})"
            
            if isinstance(staff_content[0], list):
                for voice_idx, voice_snippets in enumerate(staff_content):
                    voice_name = layout[staff_idx][voice_idx]
                    snippet_str = ' | '.join(voice_snippets)
                    print(f"      {voice_name}: {snippet_str}")
            else:
                snippet_str = ' | '.join(staff_content)
                print(f"      {staff_name}: {snippet_str}")
    
    print("\n[Assembling events from snippets...]")
    
    parts = {}
    for staff_idx, voices in enumerate(layout):
        staff_name = voices[0] if len(voices) == 1 else f"Staff{staff_idx + 1}"
        parts[staff_name] = []
    
    for section_idx, section in enumerate(sections):
        print(f"\n   Section {section_idx + 1}:")
        
        section_durations = {}
        
        for staff_idx, staff_content in enumerate(section):
            staff_name = list(parts.keys())[staff_idx]
            
            # Check if this is a multi-voice staff
            if staff_content and isinstance(staff_content[0], list):
                # Multi-voice staff: staff_content is list of voice snippet lists
                voice_names = layout[staff_idx]
                
                if len(voice_names) > 1:
                    # Process ALL voices in multi-voice staff
                    voice_events_dict = {}
                    total_ql = 0
                    
                    for voice_idx, voice_snippets in enumerate(staff_content):
                        voice_name = voice_names[voice_idx]
                        
                        # Handle rest placeholder
                        if voice_snippets == ['r']:
                            voice_events_dict[voice_name] = None  # Will fill with rests later
                            print(f"      {voice_name}: (rest - duration TBD)")
                            continue
                        
                        # Collect events for this voice
                        voice_events = []
                        for snippet_name in voice_snippets:
                            if snippet_name not in snippets:
                                raise KeyError(
                                    f"Snippet '{snippet_name}' not found. "
                                    f"Available: {list(snippets.keys())}"
                                )
                            
                            snippet_events = snippets[snippet_name]
                            voice_events.extend(snippet_events)
                            print(f"      {voice_name}: +{snippet_name} ({len(snippet_events)} events)")
                        
                        voice_events_dict[voice_name] = voice_events
                        
                        # Calculate duration for this voice
                        voice_ql = sum(e.get('ql', 0) for e in voice_events if e.get('type') != 'barline')
                        if voice_ql > total_ql:
                            total_ql = voice_ql
                    
                    # Create multi-voice section event
                    parts[staff_name].append({
                        'type': 'multi_voice_section',
                        'voices': voice_events_dict
                    })
                    
                    section_durations[staff_name] = total_ql
                else:
                    # Single voice in parentheses (treat as simple single-voice)
                    snippet_names = staff_content[0]
                    
                    if snippet_names == ['r']:
                        section_durations[staff_name] = None
                        print(f"      {staff_name}: (rest - duration TBD)")
                        continue
                    
                    staff_events = []
                    for snippet_name in snippet_names:
                        if snippet_name not in snippets:
                            raise KeyError(
                                f"Snippet '{snippet_name}' not found. "
                                f"Available: {list(snippets.keys())}"
                            )
                        
                        snippet_events = snippets[snippet_name]
                        staff_events.extend(snippet_events)
                        print(f"      {staff_name}: +{snippet_name} ({len(snippet_events)} events)")
                    
                    total_ql = sum(e.get('ql', 0) for e in staff_events if e.get('type') != 'barline')
                    section_durations[staff_name] = total_ql
                    
                    parts[staff_name].extend(staff_events)
            else:
                # Single-voice staff (simple list)
                snippet_names = staff_content
                
                if snippet_names == ['r']:
                    section_durations[staff_name] = None
                    print(f"      {staff_name}: (rest - duration TBD)")
                    continue
                
                staff_events = []
                for snippet_name in snippet_names:
                    if snippet_name not in snippets:
                        raise KeyError(
                            f"Snippet '{snippet_name}' not found. "
                            f"Available: {list(snippets.keys())}"
                        )
                    
                    snippet_events = snippets[snippet_name]
                    staff_events.extend(snippet_events)
                    print(f"      {staff_name}: +{snippet_name} ({len(snippet_events)} events)")
                
                total_ql = sum(e.get('ql', 0) for e in staff_events if e.get('type') != 'barline')
                section_durations[staff_name] = total_ql
                
                parts[staff_name].extend(staff_events)
        
        active_durations = [d for d in section_durations.values() if d is not None]
        if active_durations:
            max_duration = max(active_durations)
            
            if len(set(active_durations)) > 1:
                print(f"\n   ⚠️  WARNING: Section {section_idx + 1} has mismatched durations")
                for staff_name, duration in section_durations.items():
                    if duration is not None:
                        print(f"      {staff_name}: {duration} QL")
            
            for staff_name, duration in section_durations.items():
                if duration is None:
                    bar_duration = 4.0
                    num_bars = int(max_duration / bar_duration)
                    
                    rest_events = []
                    for _ in range(num_bars):
                        rest_events.append({'type': 'rest', 'ql': bar_duration})
                    
                    parts[staff_name].extend(rest_events)
                    print(f"      {staff_name}: Generated {num_bars} bar rests ({max_duration} QL)")
        
        for staff_name in parts.keys():
            parts[staff_name].append({'type': 'barline', 'style': '||', 'ql': 0.0})
    
    print("\n" + "="*70)
    print("BLUEPRINT ASSEMBLY COMPLETE")
    print("="*70)
    
    for staff_name, events in parts.items():
        total_ql = sum(e.get('ql', 0) for e in events if e.get('type') != 'barline')
        print(f"✓ {staff_name}: {len(events)} events ({total_ql} QL)")
    
    return {
        'metadata': metadata,
        'parts': parts
    }
