\version "2.24.1"
\header { title = "Ninth Study - Hybrid Composition" }
\score {
  <<
\new Staff {
  \clef treble
  << { c'4 bes4 aes4 g4 f2 aes2 g4 aes4 bes4 c'4 c'1 } \\ { e4 f4 g4 a4 b2 g2 c4 d4 e4 f4 g2 b2 a4 g4 f4 e4 } >>
}\new Staff {
  \clef bass
  << { a2 f2 g2 c2 e2 c2 d2 g,2 } \\ { c,2 g,2 f,2 c,2 c,2 g,2 f,2 c,2 c,2 g,2 f,2 c,2 c,2 g,2 f,2 c,2 } >>
}
>>
  \layout { }
  \midi { }
}