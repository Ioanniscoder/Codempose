\version "2.24.1"
% ========================================
% GENERATED FROM: fourteenth.py
% ========================================
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "SATB Hymn Fragment" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 4/4 \key g \major
    << { b'4 b'4 c''4 d''4 c''2 g'2 fis'4 g'4 fis'4 g'4 b'2. r4 } \\ { g4 g4 fis4 g4 c2 g2 d4 b,4 d4 g4 g2. r4 } >> \bar "||" << { g'4 g'4 g'4 a'4 b'2 e''2 d''4 d''4 b'4 a'4 b'1 } \\ { g4 g4 c'4 d'4 g'2 c'2 d'4 d'4 d'4 d'4 g1 } >> \bar "||" \break
  }
  \new Staff {
    \clef treble
    \time 4/4 \key g \major
    << { g''4 g''4 a''4 b''4 c'''2 b''2 a''4 g''4 a''4 b''4 g''2. r4 } \\ { d''4 d''4 d''4 d''4 e''2 d''2 d''4 d''4 d''4 d''4 d''2. r4 } >> \bar "||" << { b''4 b''4 c'''4 d'''4 d'''2 c'''2 b''4 a''4 g''4 fis''4 g''1 } \\ { d''4 d''4 e''4 fis''4 g''2 g''2 g''4 fis''4 e''4 d''4 d''1 } >> \bar "||" \break
  }
  >>
  \layout { }
  \midi { }
}