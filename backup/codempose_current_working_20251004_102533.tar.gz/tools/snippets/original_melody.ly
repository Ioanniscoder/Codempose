\relative e' { \time 6/4 \key c \major \tempo 4=90 e2 b c2 r | e2 f e2 r | b2. f2. | e2. c2. | e2 b2 c2 }
