\relative b' { \time 6/4 b2. f2. }
