\relative e' { \time 6/4 \key c \major \tempo 4=90 e2 b2 <e g b>2 }
