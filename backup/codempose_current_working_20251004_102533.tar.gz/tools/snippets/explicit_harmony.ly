\relative e' { \time 6/4 e2 b2 <e g b>2 }
