e2 b2 <e g b>2
