\relative c' { f32 e2 r }
