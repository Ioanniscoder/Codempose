\score {
  \new Score
  \layout { }
  \midi { }
}
