"""
Composition Shorthand - Helper Functions

This module provides tools to convert simple string expressions into
programmatic voice chains, simplifying the composition workflow.

Example usage:
    VOICE_ASSIGNMENTS = {
        'Melody': {
            'Soprano': 'V1 + V2',    # Chain
            'Alto': 'V2 * 2',        # Repeat
        }
    }
    
    score_data = build_score_from_assignments(VOICE_ASSIGNMENTS, voice_data)
"""

def parse_voice_assignment(expression: str, voice_lookup: dict) -> list:
    """
    Convert shorthand expression to event list.
    
    Supported syntax:
        'V1'           -> voice1_events
        'V1 + V2'      -> voice1_events + voice2_events
        'V1 * 3'       -> voice1_events * 3
        'V1 + V2 * 2'  -> voice1_events + (voice2_events * 2)
    
    Args:
        expression: Shorthand string (e.g., 'V1 + V2')
        voice_lookup: Dict mapping 'V1' -> voice1_events
    
    Returns:
        Combined event list
    
    Examples:
        >>> voices = {'V1': [1, 2], 'V2': [3, 4]}
        >>> parse_voice_assignment('V1 + V2', voices)
        [1, 2, 3, 4]
        >>> parse_voice_assignment('V1 * 2', voices)
        [1, 2, 1, 2]
    """
    # Split by + operator (chain)
    parts = [p.strip() for p in expression.split('+')]
    result = []
    
    for part in parts:
        # Check for repetition (V1 * 3)
        if '*' in part:
            voice_name, count = [x.strip() for x in part.split('*')]
            count = int(count)
            if voice_name not in voice_lookup:
                raise ValueError(f"Voice '{voice_name}' not found in voice_lookup. Available: {list(voice_lookup.keys())}")
            result.extend(voice_lookup[voice_name] * count)
        else:
            # Simple voice reference
            if part not in voice_lookup:
                raise ValueError(f"Voice '{part}' not found in voice_lookup. Available: {list(voice_lookup.keys())}")
            result.extend(voice_lookup[part])
    
    return result


def build_score_from_assignments(voice_assignments: dict, voice_data: dict, metadata: dict = None) -> dict:
    """
    Auto-generate score_data from VOICE_ASSIGNMENTS shorthand.
    
    Args:
        voice_assignments: Structure definition
            Example: {
                'Melody': {
                    'Soprano': 'V1 + V2',
                    'Alto': 'V2 * 2',
                }
            }
        voice_data: Parsed voice data
            Example: {
                'V1': voice1_events,
                'V2': voice2_events,
            }
        metadata: Optional metadata dict (title, tempo, etc.)
    
    Returns:
        Complete score_data structure ready for engraving
    
    Example:
        >>> voice_assignments = {'Melody': {'Soprano': 'V1 + V2'}}
        >>> voice_data = {'V1': [1, 2], 'V2': [3, 4]}
        >>> result = build_score_from_assignments(voice_assignments, voice_data)
        >>> result['parts']['Melody']['Soprano']
        [1, 2, 3, 4]
    """
    parts = {}
    
    for staff_name, voices in voice_assignments.items():
        parts[staff_name] = {}
        for voice_name, expression in voices.items():
            parts[staff_name][voice_name] = parse_voice_assignment(expression, voice_data)
    
    score_data = {'parts': parts}
    
    if metadata:
        score_data['metadata'] = metadata
    
    return score_data


def format_voice_assignment_docs(voice_assignments: dict, voice_snippets: dict) -> str:
    """
    Generate human-readable documentation for VOICE_ASSIGNMENTS.
    
    This creates the comment text that appears in .ly files showing
    how voices were constructed from snippets.
    
    Args:
        voice_assignments: The VOICE_ASSIGNMENTS structure
        voice_snippets: Dict mapping voice names to (LILY, TINY) tuples
            Example: {
                'V1': (VOICE_1_LILY, VOICE_1_TINY),
                'V2': (VOICE_2_LILY, VOICE_2_TINY),
            }
    
    Returns:
        Formatted documentation string
    """
    lines = ["COMPOSITION STRUCTURE:", ""]
    
    for staff_name, voices in voice_assignments.items():
        lines.append(f"{staff_name.upper()} STAFF:")
        lines.append("")
        
        for voice_name, expression in voices.items():
            lines.append(f"{voice_name}: {expression}")
            
            # Parse expression to show what snippets are used
            snippets_used = set()
            for part in expression.replace('*', '+').split('+'):
                part = part.strip().split()[0]  # Get voice name only
                if part in voice_snippets:
                    snippets_used.add(part)
            
            # Show each snippet
            for snippet_name in sorted(snippets_used):
                lily, tiny = voice_snippets[snippet_name]
                lines.append(f"  {snippet_name}:")
                lines.append(f"    LILYPOND: {lily[:60]}...")
                lines.append(f"    TINY: {tiny[:60]}...")
            lines.append("")
    
    return "\n".join(lines)


# Example usage demonstration
if __name__ == '__main__':
    # Simulated voice events
    v1 = [{'type': 'note', 'step': 'c', 'octave': 5, 'ql': 1.0}]
    v2 = [{'type': 'note', 'step': 'e', 'octave': 4, 'ql': 1.0}]
    
    voice_data = {'V1': v1, 'V2': v2}
    
    # Test simple chain
    result = parse_voice_assignment('V1 + V2', voice_data)
    assert len(result) == 2, "Chain should have 2 events"
    
    # Test repetition
    result = parse_voice_assignment('V1 * 3', voice_data)
    assert len(result) == 3, "Repeat should have 3 events"
    
    # Test complex
    result = parse_voice_assignment('V1 + V2 * 2', voice_data)
    assert len(result) == 3, "Mixed should have 3 events"
    
    # Test full build
    assignments = {
        'Melody': {
            'Soprano': 'V1',
            'Alto': 'V1 + V2',
        }
    }
    
    score = build_score_from_assignments(assignments, voice_data)
    assert len(score['parts']['Melody']['Soprano']) == 1
    assert len(score['parts']['Melody']['Alto']) == 2
    
    print("✅ All tests passed!")
    print("\nExample score structure:")
    print(f"  Soprano: {len(score['parts']['Melody']['Soprano'])} events")
    print(f"  Alto: {len(score['parts']['Melody']['Alto'])} events")
