\version "2.24.1"
% ========================================
% ORIGINAL LILYPOND INPUT (for reference)
% ========================================
% TREBLE STAFF (Melody):
% 
% Voice 1 (Soprano - 4 bars):
% LILYPOND FORMAT:
% \relative c'' {
%     \time 4/4
%     \key c \major
%     \tempo 4=120
%     c4 d e f |
%     g2 e4 c |
%     d4 e f d |
%     e2. r4
% }
% 
% TINYNOTATION FORMAT:
% c'4 d'4 e'4 f'4 g'2 e'4 c'4 d'4 e'4 f'4 d'4 e'2. r4
% 
% Voice CHAINED (Alto - 8 bars):
% PROGRAMMATICALLY CHAINED in build_score_data():
%   voice_chained_events = voice1_events + voice2_events
% 
% Built from Voice 1 + Voice 2:
% LILYPOND FORMAT (Voice 2):
% \relative c' {
%     e4 f g a |
%     b2 c4 g |
%     a4 b c a |
%     b2. r4
% }
% 
% TINYNOTATION FORMAT (Voice 2):
% e4 f4 g4 a4 b2 c'4 g4 a4 b4 c'4 a4 b2. r4
% 
% BASS STAFF (Harmony):
% 
% Voice 3 (Tenor):
% LILYPOND FORMAT:
% \relative c' {
%     g4 a b c |
%     d2 c4 e |
%     f4 g a f |
%     g2. r4
% }
% 
% TINYNOTATION FORMAT:
% g4 a4 b4 c'4 d'2 c'4 e'4 f'4 g'4 a'4 f'4 g'2. r4
% 
% Voice 4 (Bass):
% LILYPOND FORMAT:
% \relative c {
%     c4 f, g a |
%     g2 c4 c |
%     d4 g, f f |
%     c2. r4
% }
% 
% TINYNOTATION FORMAT:
% c4 F4 G4 A4 G2 c4 c4 d4 G4 F4 F4 c2. r4
%
% ========================================

\header { title = "Sixth Study - Programmatic Voice Chaining" }
\score {
  <<
\new Staff {
  \clef treble
  \time 4/4 \key c \major \tempo 4 = 120
  << { c'4 d'4 e'4 f'4 g'2 e'4 c'4 d'4 e'4 f'4 d'4 e'2. r4 } \\ { c'4 d'4 e'4 f'4 g'2 e'4 c'4 d'4 e'4 f'4 d'4 e'2. r4 e4 f4 g4 a4 b2 c'4 g'4 a'4 b'4 c''4 a'4 b'2. r4 } >>
}\new Staff {
  \clef bass
  \time 4/4 \key c \major \tempo 4 = 120
  << { g4 a4 b4 c'4 d'2 c'4 e'4 f'4 g'4 a'4 f'4 g'2. r4 } \\ { c,4 f,4 g,4 a,4 g,2 c,4 c,4 d,4 g,4 f,4 f,4 c,2. r4 } >>
}
>>
  \layout { }
  \midi { }
}