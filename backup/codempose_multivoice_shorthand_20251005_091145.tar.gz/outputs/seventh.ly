\version "2.24.1"
% ========================================
% ORIGINAL LILYPOND INPUT (for reference)
% ========================================
% COMPOSITION STRUCTURE (from VOICE_ASSIGNMENTS):
% 
% Melody Staff:
%   Soprano: INTRO + THEME + VARIATION + THEME + CODA
%   Alto: THEME * 3 + CODA
% 
% Harmony Staff:
%   Tenor: HARMONY * 2 + HARMONY
%   Bass: BASS * 5
% 
% VOICE SNIPPETS:
% 
% INTRO:
% LILYPOND FORMAT:
% \relative c'' {
%     \time 4/4
%     \key c \major
%     \tempo 4=120
%     c2 e2 |
%     d2 f2 |
% }
% TINYNOTATION FORMAT:
% c'2 e'2 d'2 f'2
% 
% THEME:
% LILYPOND FORMAT:
% \relative c'' {
%     g4 e4 c4 d4 |
%     e2 d2 |
% }
% TINYNOTATION FORMAT:
% g'4 e'4 c'4 d'4 e'2 d'2
% 
% VARIATION:
% LILYPOND FORMAT:
% \relative c'' {
%     g4 f4 e4 d4 |
%     c2 b2 |
% }
% TINYNOTATION FORMAT:
% g'4 f'4 e'4 d'4 c'2 b2
% 
% CODA:
% LILYPOND FORMAT:
% \relative c'' {
%     c4 b4 c4 d4 |
%     c1 |
% }
% TINYNOTATION FORMAT:
% c'4 b4 c'4 d'4 c'1
% 
% BASS:
% LILYPOND FORMAT:
% \relative c {
%     c2 g2 |
%     f2 g2 |
% }
% TINYNOTATION FORMAT:
% c2 G2 F2 G2
% 
% HARMONY:
% LILYPOND FORMAT:
% \relative c' {
%     e2 g2 |
%     a2 b2 |
% }
% TINYNOTATION FORMAT:
% e2 g2 a2 b2
%
% ========================================

\header { title = "Seventh Study - Shorthand Composition (ABA Form)" }
\score {
  <<
\new Staff {
  \clef treble
  \time 4/4 \key c \major \tempo 4 = 120
  << { c'2 e'2 d'2 f'2 g'4 e'4 c'4 d'4 e'2 d'2 g'4 f'4 e'4 d'4 c'2 b2 g'4 e'4 c'4 d'4 e'2 d'2 c'4 b4 c'4 d'4 c'1 } \\ { g'4 e'4 c'4 d'4 e'2 d'2 g'4 e'4 c'4 d'4 e'2 d'2 g'4 e'4 c'4 d'4 e'2 d'2 c'4 b4 c'4 d'4 c'1 } >>
}\new Staff {
  \clef bass
  \time 4/4 \key c \major \tempo 4 = 120
  << { e2 g2 a2 b2 e2 g2 a2 b2 e2 g2 a2 b2 } \\ { c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 } >>
}
>>
  \layout { }
  \midi { }
}