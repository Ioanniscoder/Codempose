\version "2.24.1"
% ========================================
% ORIGINAL LILYPOND INPUT (for reference)
% ========================================
% LILYPOND FORMAT:
% \relative e' {
%     \time 6/4
%     \key c \major
%     \tempo 4=90
%     e2 bmol4 c2 r4 |
%     e2 f#4 e2 r4 |
%     b2. f'2. |
%     e2. c2. |
%     e2 b2 c2
% }
% 
% TINYNOTATION FORMAT:
% time=6/4 key=Cmajor tempo=90 e2 b-4 c'2 r4 e'2 f#'4 e'2 r4 b'2. f''2. e''2. c''2. e''2 b''2 c'''2
%
% ========================================

\header { title = "First Study - Two-Part Composition" }
\score {
  <<
\new Staff {
  \clef treble
  \time 6/4 \key c \major \tempo 4 = 90
  e2 bes4 c'2 r4 e'2 fis4 e'2 r4 b'2. f''2. e''2. c''2. e''2 b''2 c'''2
}\new Staff {
  \clef bass
  \time 6/4 \key c \major \tempo 4 = 90
  e,,2 b,,2 c,2 f,2 g,2 c2
}
>>
  \layout { }
  \midi { }
}