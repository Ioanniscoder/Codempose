\version "2.24.1"
% ========================================
% GENERATED FROM: test_two_staves.py
% ========================================
%
% ========================================
% ORIGINAL SNIPPETS (Station 1 & 2)
% ========================================
%
% LilyPond Format:
%   INTERMEZZO:
%     \relative c' {
%         \time 4/4
%         \key c \major
%         <c e g>2 <d f a>2 |
%         <e g b>2 <f a c>2
%     }
%
%   THEME_A:
%     \relative c' {
%         \time 4/4
%         \key c \major
%         \tempo 4=120
%         c4 d4 e4 f4 |
%         e2 d2 |
%         c1
%     }
%
% ========================================
% VOICE TRACKING (Station 4 - Detailed)
% ========================================
%
% LowerStaff:
%   Transformation: unknown
%   Description: 
%   Events: 0
%
% UpperStaff:
%   Transformation: unknown
%   Description: 
%   Events: 0
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Two-Stave Test: Theme A + Harmony" }
\score {
  \new StaffGroup <<
\new Staff {
  \clef treble
  \time 4/4
  c''4 d''4 e''4 f''4 e''2 d''2 c''1 \bar "||" r1... \bar "||" g''4 a''4 b''4 c'''4 b''2 a''2 g''1 \bar "||" r1... \bar "||" c'4 bes'4 aes'4 g'4 aes'2 bes'2 c'1
}\new Staff {
  \clef bass
  \time 4/4
  r1... \bar "||" r1... \bar "||" r1... \bar "||" r1... \bar "||" r1...
}
>>
  \layout { }
  \midi { }
}