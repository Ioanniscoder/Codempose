\version "2.24.1"
% ========================================
% GENERATED FROM: eleventh.py
% ========================================
%
% ========================================
% TINYNOTATION INSPECTOR (Diagnostic)
% ========================================
% This TinyNotation string shows how the parser
% resolved relative pitches. Use it to verify
% octave resolution is working correctly.
%
%   6/4 e2 b,4 c2 r4 e2 f4 e2 r4 b,2. f'2. e'2. c'2. e'2 b2 c'2
%
% ========================================
% ORIGINAL LILYPOND INPUT
% ========================================
%
% \relative e { \time 6/4 \key c \major \tempo 4=90 e2 b4 c2 r4 | e2 f4 e2 r4 | b2. f'2. | e2. c2. | e2 b2 c2 }
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "LilyPond Score" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    b'2 fis'4 g'2 r4 b'2 c''4 b'2 r4 fis'2. c'''2. b''2. g''2. b''2 fis''2 g''2
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    c''2 b'2 e''2 c''2. e''2. f''2. b2. r4 e'2 f'4 e'2 r4 c'2 b4 e'2
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    e'2 b4 c'2 r4 e'2 f'4 e'2 r4 b2. f''2. e''2. c''2. e''2 b'2 c''2
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    aes'2 b'4 c''2 r4 aes'2 g'4 aes'2 r4 b'2. g'2. aes'2. c'2. aes'2 des'2 c'2
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    e'4 b8 c'4 r8 e'4 f'8 e'4 r8 b4. f''4. e''4. c''4. e''4 b'4 c''4
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f'' a'' c'''>2. <e'' gis'' b''>2. <c'' e'' g''>2. <e'' gis'' b''>2 <b' dis'' fis''>2 <c'' e'' g''>2
  }
  \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    e'1 b2 c'1 r2 e'1 f'2 e'1 r2 b1. f''1. e''1. c''1. e''1 b'1 c''1
  }
  >>
  \layout { }
  \midi { }
}