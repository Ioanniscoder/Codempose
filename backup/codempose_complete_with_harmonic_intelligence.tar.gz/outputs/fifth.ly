\version "2.24.1"
% ========================================
% GENERATED FROM: fifth.py
% ========================================
%
% ========================================
% TINYNOTATION INSPECTOR (Diagnostic)
% ========================================
% This TinyNotation string shows how the parser
% resolved relative pitches. Use it to verify
% octave resolution is working correctly.
%
%   4/4 c'4 None'2 r4 None'4 g'8 None'4. r4 None'1
%
% ========================================
% ORIGINAL LILYPOND INPUT
% ========================================
%
% 
% \relative c' {
%     \time 4/4
%     \key c \major
%     c4 <e g>2 r4 |
%     <d f a>4 g8 <f a c'>4. r4 |
%     <c e g c'>1
% }
% 
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "LilyPond Score" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
      \new Staff {
    \clef treble
    \time 4/4 \key c \major
    c''4 <e'' g''>2 r4 <d'' f'' a''>4 g''8 <f'' a'' c''''>4. r4 <c'' e'' g'' c''''>1
  }

  \layout { }
  \midi { }
}