\version "2.24.1"
% ========================================
% ORIGINAL LILYPOND INPUT (for reference)
% ========================================
% COMPOSITION STRUCTURE (Enhanced Shorthand with Transformations):
% 
% Melody Staff:
%   Soprano: THEME + transpose(THEME, 7) + invert(THEME) + THEME
%   Alto: retrograde(VARIATION) + VARIATION
% 
% Harmony Staff:
%   Tenor: transpose(BASS, 5) + BASS
%   Bass: BASS * 4
% 
% TRANSFORMATIONS USED:
%   - transpose(V, N) = Transpose voice V up N semitones
%   - invert(V) = Melodic inversion of voice V around C4
%   - retrograde(V) = Reverse voice V (play backwards)
% 
% VOICE SNIPPETS:
% 
% THEME:
% LILYPOND FORMAT:
% \relative c'' {
%     \time 4/4
%     \key c \major
%     \tempo 4=120
%     c4 d4 e4 f4 |
%     g2 e2 |
% }
% TINYNOTATION FORMAT:
% c'4 d'4 e'4 f'4 g'2 e'2
% 
% VARIATION:
% LILYPOND FORMAT:
% \relative c'' {
%     g4 f4 e4 d4 |
%     c2 e2 |
% }
% TINYNOTATION FORMAT:
% g'4 f'4 e'4 d'4 c'2 e'2
% 
% BASS:
% LILYPOND FORMAT:
% \relative c {
%     c2 g2 |
%     f2 g2 |
% }
% TINYNOTATION FORMAT:
% c2 G2 F2 G2
%
% ========================================

\header { title = "Eighth Study - Algorithmic Composition (Transformations)" }
\score {
  <<
\new Staff {
  \clef treble
  \time 4/4 \key c \major \tempo 4 = 120
  << { c'4 d'4 e'4 f'4 g'2 e'2 g'4 a'4 b'4 c''4 d''2 b'2 c,4 ais,,4 gis,,4 g,,4 f,,2 gis,,2 c'4 d'4 e'4 f'4 g'2 e'2 } \\ { e'2 c'2 d'4 e'4 f'4 g'4 g'4 f'4 e'4 d'4 c'2 e'2 } >>
}\new Staff {
  \clef bass
  \time 4/4 \key c \major \tempo 4 = 120
  << { f,2 c2 ais,2 c2 c,2 g,2 f,2 g,2 } \\ { c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 c,2 g,2 f,2 g,2 } >>
}
>>
  \layout { }
  \midi { }
}