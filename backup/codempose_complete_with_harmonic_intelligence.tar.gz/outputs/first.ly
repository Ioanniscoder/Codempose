\version "2.24.1"
% ========================================
% GENERATED FROM: first.py
% ========================================
%
% ========================================
% TINYNOTATION INSPECTOR (Diagnostic)
% ========================================
% This TinyNotation string shows how the parser
% resolved relative pitches. Use it to verify
% octave resolution is working correctly.
%
%   6/4 e2 b-4 c'2 r4 e'2 f#'4 e'2 r4 b2. f''2. e''2. c''2. e''2 b'2 c''2
%
% ========================================
% ORIGINAL LILYPOND INPUT
% ========================================
%
% \relative e { \time 6/4 \key c \major \tempo 4=90 e2 bmol4 c2 r4 | e2 f#4 e2 r4 | b2. f'2. | e2. c2. | e2 b2 c2 }
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "LilyPond Score" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
      \new Staff {
    \clef treble
    \time 6/4 \key c \major \tempo 4 = 90
    e'2 bes'4 c''2 r4 e''2 fis''4 e''2 r4 b'2. f'''2. e'''2. c'''2. e'''2 b''2 c'''2
  }

  \layout { }
  \midi { }
}