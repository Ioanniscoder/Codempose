\version "2.24.1"
% ========================================
% GENERATED FROM: seventeenth.py
% ========================================
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "50s Progression Demo" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 4/4 \key c \major \tempo 4 = 100
    c'''4 e'''4 g'''4 e'''4 a'''4 g'''4 f'''4 e'''4 f'''4 d'''4 e'''4 c'''4 d'''4 c'''4 b''4 c'''4 c'''1
  }
  \new Staff {
    \clef bass
    \time 4/4 \key c \major \tempo 4 = 100
    c2. a2. f2. g2. c2.
  }
  >>
  \layout { }
  \midi { }
}