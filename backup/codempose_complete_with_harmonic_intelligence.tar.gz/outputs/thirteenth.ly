\version "2.24.1"
% ========================================
% GENERATED FROM: thirteenth.py
% ========================================
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Thirteenth Study: Complete Parser Feature Showcase" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 4/4 \key c \major
    c''4 \tuplet 3/2 { d''8 e''8 f''8 } e''2 g''64 a''2\p \tuplet 3/2 { b''8 c'''8 d'''8 } c'''4 \tuplet 3/2 { e'''8 f'''8 g'''8 } f'''4 e'''2 d'''4 c'''64 e'''2 e'''4 r1 \bar "||" r1 r1 \bar "||" \break
    g''4 a''16. b''16. c'''16. b''2 d'''4 e'''2 fis'''16. g'''16. a'''16. g'''4 b'''16. c''''16. d''''16. c''''4 b'''2 a'''4 g'''4 b'''2 b'''4 r1 \bar "||" r1 r1 \bar "||" \break
    c'4 bes'16. aes'16. g'16. aes'2 f'4 ees'2 des'16. c'16. bes'16. c'4 aes'16. g'16. f'16. g'4 aes'2 bes'4 c'4 aes'2 aes'4 r1 \bar "||" r1 r1 \bar "||" \break
    <c' e' g'>4 <d' fis' a'>16. <e' gis' b'>16. <f' a' c''>16. <e' gis' b'>2 <g' b' d''>4 <a' cis'' e''>2 <b' dis'' fis''>16. <c'' e'' g''>16. <d'' fis'' a''>16. <c'' e'' g''>4 <e'' gis'' b''>16. <f'' a'' c'''>16. <g'' b'' d'''>16. <f'' a'' c'''>4 <e'' gis'' b''>2 <d'' fis'' a''>4 <c'' e'' g''>4 <e'' gis'' b''>2 <e'' gis'' b''>4 r1 \bar "||"
  }
  \new Staff {
    \clef bass
    \time 4/4 \key c \major
    r1 r1 r1 r1 \bar "||" <c e g>2 <d f a>2 <e g b>2 <f a c'>2 \bar "||" \break
    r1 r1 r1 r1 r1 \bar "||" <c e g>2 <d f a>2 <e g b>2 <f a c'>2 \bar "||" \break
    r1 r1 r1 r1 r1 \bar "||" <c e g>2 <d f a>2 <e g b>2 <f a c'>2 \bar "||" \break
    r1 r1 r1 r1 r1 \bar "||"
  }
  >>
  \layout { }
  \midi { }
}