\version "2.24.1"
% ========================================
% GENERATED FROM: ninetyninth.py
% ========================================
%
% ========================================
% BLUEPRINT STRUCTURE (Station 3)
% ========================================
%
% VOICE_STAVE_DEF:
%   Melody & Bass
%
% VOICE_STAVE_DATA:
%   # Section 1: Exposition
%   THEME_A & bass_figure;
%   # Section 2: Development with transposition (using music21 transformation!)
%   transpose_part(THEME_A, 'P4') & bass_figure;
%   # Section 3: Contrasting material
%   THEME_B & r;
%   # Section 4: Recapitulation with repetition
%   THEME_A * 2 & bass_figure * 2
%
% ========================================
% ORIGINAL SNIPPETS (Station 1 & 2)
% ========================================
%
% LilyPond Format:
%   HARMONY_CHORDS (9.0 QL, 3 bars, 3/4):
%     \relative c' {
%         \key g \major
%         \time 3/4
%         <g b d>2. |
%         <a c e>2. |
%         <g b d>2.
%     }
%
%   THEME_A (12.0 QL, 4 bars, 3/4):
%     \relative c'' {
%         \key g \major
%         \time 3/4
%         \tempo "Andante" 4=90
%         \mark \markup { \bold \box "Main Theme" }
%         d4-.\p( fis8 g) a4~ |      % Staccato, piano, slur, tie
%         a4 g4->( fis) |             % Accent, phrase
%         e4.( d8~ d4) |              % Dotted rhythm
%         b'4\f c4 d4                % Forte, climax
%     }
%
%   THEME_B (12.0 QL, 4 bars, 3/4):
%     \relative c' {
%         \key g \major
%         \time 3/4
%         g4( fis e) |
%         d2.~ |
%         d4 e fis |
%         g2.
%     }
%
%   bass_figure (12.0 QL, 4 bars, 3/4):
%     \relative c {
%         \clef bass
%         \key g \major
%         \time 3/4
%         g4 d' b |
%         c2 b4 |
%         a4 g fis |
%         g2.
%     }
%
% ========================================
% REFERENCE
% ========================================
% This header shows the original composition structure:
% - Blueprint strings define the musical form
% - Original LilyPond snippets show the source material
% - TinyNotation provides an alternative notation view
%
% Use this as reference when modifying or extending the composition.
% ========================================
\header {
  title = "NINETYNINTH Study: Clean Header Test"
  composer = "Codempose Framework"
  opus = "NINETYNINTH"
  subtitle = "Based on: HARMONY_CHORDS, THEME_A, THEME_B, bass_figure"
}

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 3/4 \key g \major
    d4-.\p( fis8 g) a4~ |      % Staccato, piano, slur, tie
    a4 g4->( fis) |             % Accent, phrase
    e4.( d8~ d4) |              % Dotted rhythm
    b'4\f c4 d4                % Forte, climax | \bar "||" \break
    g'''4 b'''8 c''''8 d''''4 | d''''4 c''''4 b'''4 | a'''4. g'''8 g'''4 | e''''4 f''''4 g''''4 | \bar "||" \break
    \mark "B" g4( fis e) |
    d2.~ |
    d4 e fis |
    g2. | \bar "||" \break
    d4-.\p( fis8 g) a4~ |      % Staccato, piano, slur, tie
    a4 g4->( fis) |             % Accent, phrase
    e4.( d8~ d4) |              % Dotted rhythm
    b'4\f c4 d4                % Forte, climax | \bar "||" \break
    d4-.\p( fis8 g) a4~ |      % Staccato, piano, slur, tie
    a4 g4->( fis) |             % Accent, phrase
    e4.( d8~ d4) |              % Dotted rhythm
    b'4\f c4 d4                % Forte, climax | \bar "||" \break
  }
  \new Staff {
    \clef bass
    \time 3/4 \key g \major
    g4 d' b |
    c2 b4 |
    a4 g fis |
    g2. | \bar "||" \break
    g4 d' b |
    c2 b4 |
    a4 g fis |
    g2. | \bar "||" \break
    r2. | \bar "|" r2. | \bar "|" r2. | \bar "|" r2. | \bar "||" \break
    g4 d' b |
    c2 b4 |
    a4 g fis |
    g2. | \bar "||" \break
    g4 d' b |
    c2 b4 |
    a4 g fis |
    g2. | \bar "||" \break
  }
  >>
  \layout {
    \context {
      \Staff
      % Keep empty staves visible (don't remove them automatically)
      \RemoveEmptyStaves ##f
    }
  }
  \midi { }
}