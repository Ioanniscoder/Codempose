\version "2.24.1"
% ========================================
% GENERATED FROM: fourteenth.py
% ========================================
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "SATB Hymn Fragment" }

\paper {
  indent = 0\mm
  line-width = 180\mm
  ragged-right = ##f
  ragged-last = ##f
  page-breaking = #ly:optimal-breaking
  system-system-spacing.basic-distance = #12
  system-system-spacing.minimum-distance = #8
  system-system-spacing.padding = #1
  score-system-spacing.basic-distance = #14
}

\score {
    \new StaffGroup <<
  \new Staff {
    \clef treble
    \time 4/4 \key g \major
    \bar "||" \bar "||" \break
  }
  \new Staff {
    \clef treble
    \time 4/4 \key g \major
    \bar "||" \bar "||" \break
  }
  >>
  \layout { }
  \midi { }
}