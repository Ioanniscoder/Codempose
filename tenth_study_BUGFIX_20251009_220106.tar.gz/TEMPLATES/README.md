# CODEMPOSE TEMPLATES

This directory contains template files for creating new Codempose studies.

## Available Templates

### study_template.py
A complete template demonstrating the four-station workflow:
- Station 1: LilyPond original snippets
- Station 2: TinyNotation equivalents
- Station 3: Shorthand structure
- Station 4: Programmatic generation

**To use:**
1. Copy `study_template.py` to the main directory
2. Rename it (e.g., `eleventh.py`)
3. Customize the musical content
4. Run: `python3 eleventh.py`

## Template Features

✅ **Promotion Toggles**
- `PROMOTE_TO_TINYNOTATION`: Toggle format dominance
- `PROMOTE_TO_PROGRAMMATIC`: Toggle shorthand vs. programmatic

✅ **Both Approaches**
- `build_score_data()`: Hybrid approach with shorthand
- `build_score_data_programmatic()`: Pure programmatic

✅ **Documentation**
- Automatically generates comprehensive documentation
- Shows both LilyPond and TinyNotation formats
- Includes source attribution

✅ **Multi-Format Output**
- LilyPond (.ly)
- PDF score
- MIDI playback
- MusicXML (MuseScore)

## Workflow

1. **Define Snippets** (Station 1)
   ```python
   MELODY_LILY = r"\relative c' { c4 d e f | }"
   ```

2. **Add TinyNotation** (Station 2)
   ```python
   MELODY_TINY = "tinynotation: 4/4 c4 d e f"
   ```

3. **Create Shorthand** (Station 3)
   ```python
   VOICE_ASSIGNMENTS = {
       'Treble': {'Melody': 'MELODY * 2'}
   }
   ```

4. **Generate Programmatically** (Station 4)
   ```python
   melody_inverted = invert_events(melody, 'c4')
   register_and_document_voice('MELODY_INV', melody_inverted, ...)
   ```

## Best Practices

- Start simple: Use basic LilyPond snippets first
- Test early: Run `python3 your_study.py` frequently
- Document as you go: Use `register_and_document_voice()` for programmatic voices
- Review outputs: Check `outputs/` directory for all generated files
- Use promotion: Enable toggles to experiment with different approaches

## Output Structure

Running a study generates:
```
outputs/
├── your_study.py        # Source copy
├── your_study.ly        # LilyPond with documentation
├── your_study.pdf       # Musical score
├── your_study.midi      # Audio playback
└── your_study.musicxml  # MuseScore import
```

## Need Help?

- Check existing studies: `first.py` through `tenth.py`
- Read documentation: `DOCUMENTATION_INDEX.md`
- Review code flow: `CODE_FLOW_ANALYSIS.md`
