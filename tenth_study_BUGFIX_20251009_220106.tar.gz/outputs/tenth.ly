\version "2.24.1"
% ========================================
% GENERATED FROM: tenth.py
% ========================================
%
% ========================================
% ORIGINAL SNIPPETS (Station 1 & 2)
% ========================================
%
% LilyPond Format:
%   ALTO_THEME_LILY:
%     \relative c' { \time 4/4 \key c \major c4 b8 a8 g4 f4 | e2 f2 | }
%
%   BASS_PATTERN_LILY:
%     \relative c { \time 4/4 \key c \major c2 g2 | f2 c2 | }
%
%   SOPRANO_THEME_LILY:
%     \relative c'' { \time 4/4 \key c \major e4 d8 c8 b4 a4 | g2 a2 | }
%
% TinyNotation Format:
%   ALTO_THEME_TINY:
%     tinynotation: 4/4 c'4 b8 a8 g4 f4 e2 f2
%
%   BASS_PATTERN_TINY:
%     tinynotation: 4/4 c2 G2 F2 C2
%
%   SOPRANO_THEME_TINY:
%     tinynotation: 4/4 e'4 d'8 c'8 b4 a4 g2 a2
%
% ========================================
% SHORTHAND STRUCTURE (Station 3)
% ========================================
%
%   Harmony.Bass: BASS_PATTERN + BASS_GENERATED
%   Harmony.Tenor: TENOR_GENERATED + transpose(BASS_PATTERN, 12)
%   Melody.Alto: ALTO_GENERATED * 2
%   Melody.Soprano: SOPRANO_THEME + ALTO_GENERATED
%
% ========================================
% PROGRAMMATIC VOICES (Station 4)
% ========================================
%
% ALTO_GENERATED:
%   \relative c' { \time 4/4 \key c \major a'4 g'8 f'8 e'4 d'4 c'2 d'2 }
%
% BASS_GENERATED:
%   \relative c { \time 4/4 \key c \major c,4 }
%
% TENOR_GENERATED:
%   \relative c' { \time 4/4 \key c \major c'4 }
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Tenth Study: Complete Four-Station Workflow" }
\score {
  <<
\new Staff {
  \clef treble
  \time 4/4 \key c \major
  << { e'4 d'8 c'8 b4 a4 g2 a2 a4 g8 f8 e4 d4 c2 d2 } \\ { a4 g8 f8 e4 d4 c2 d2 a4 g8 f8 e4 d4 c2 d2 } >>
}\new Staff {
  \clef bass
  \time 4/4 \key c \major
  << { c4 } \\ { c,4 } >>
}
>>
  \layout { }
  \midi { }
}