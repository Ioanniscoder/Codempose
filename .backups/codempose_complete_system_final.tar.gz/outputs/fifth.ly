\version "2.24.1"
\header { title = "LilyPond Score" }
\score {
  \new Staff {
  \clef treble
  
\relative c' {
    \time 4/4
    \key c \major
    c4 <e g>2 r4 |
    <d f a>4 g8 <f a c'>4. r4 |
    <c e g c'>1
}

}
  \layout { }
  \midi { }
}