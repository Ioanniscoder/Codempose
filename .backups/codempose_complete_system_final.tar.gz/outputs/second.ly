\version "2.24.1"
\header { title = "LilyPond Score" }
\score {
  <<
\new Staff {
  \clef bass
  <e>4 <b>4 <e''>4 <b''>4 <b>4 <fis'>4 <b''>4 <fis'''>4 <e'>4 <ees'>4 <bes>4 <ees'>4 <fis'''>4 <b''>4 <fis'>4 <b>4
}\new Staff {
  \clef treble
  e4 b4 e''4 b''4 b4 fis'4 b''4 fis'''4 e'4 ees'4 bes4 ees'4 fis'''4 b''4 fis'4 b4
}
>>
  \layout { }
  \midi { }
}