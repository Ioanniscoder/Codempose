\version "2.24.1"
\header { title = "LilyPond Score" }
\score {
  \new Staff {
  \clef treble
  c4 d4 e4 f4 g4 a4 b4 c'4
}
  \layout { }
  \midi { }
}