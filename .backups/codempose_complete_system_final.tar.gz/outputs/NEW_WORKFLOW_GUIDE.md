# 🎵 Codempose New Workflow Guide

**Date:** October 3, 2025  
**Status:** ✅ Active  
**Previous Workflow:** DEPRECATED

---

## 🚀 **The New Way: Self-Executing Study Files**

Study files are now **self-executing**! Just run them directly:

```bash
python first.py    # ✅ Generates outputs/first.{ly,pdf,midi}
python second.py   # ✅ Generates outputs/second.{ly,pdf,midi}
python third.py    # ✅ Generates outputs/third.{ly,pdf,midi}
```

---

## 📋 **What Changed**

### **Before (Deprecated)**
```bash
python main.py first.py   # ❌ Cumbersome
python main.py third.py   # ❌ External launcher required
```

**Problems:**
- ❌ Required external launcher (`main.py`)
- ❌ Lost flexibility (only worked with `build_score_data()`)
- ❌ Unintuitive workflow

### **After (New)**
```bash
python first.py    # ✅ Direct execution
python third.py    # ✅ Self-contained
```

**Benefits:**
- ✅ Direct execution - no external launcher needed
- ✅ Flexible input handling - three priority levels
- ✅ Intuitive workflow - file is the entry point
- ✅ Self-documenting - run the file you're working on

---

## 🎯 **How It Works: The Three Stations**

The new `run_pipeline_from_file()` function in `project_template.py` implements intelligent input detection with **priority order**:

### **Priority 1: `build_score_data()` Function** (Highest)
For programmatic composition with full control.

```python
# third.py example
def build_score_data():
    return {
        'metadata': {'title': 'My Composition'},
        'parts': {
            'Main Melody': [
                {'type': 'note', 'step': 'C', 'octave': 4, 'ql': 1.0},
                # ... more events
            ]
        }
    }

if __name__ == '__main__':
    from project_template import run_pipeline_from_file
    run_pipeline_from_file(__file__)
```

### **Priority 2: `SOURCE_MELODY_LILY` Variable** (Second)
For simple LilyPond string input.

```python
# first.py example
SOURCE_MELODY_LILY = r"\relative c' { c4 d e f g a b c }"

if __name__ == '__main__':
    from project_template import run_pipeline_from_file
    run_pipeline_from_file(__file__)
```

### **Priority 3: `build_part()` Function** (Third)
For music21.Part generation.

```python
# example (not used in current study files)
def build_part():
    part = music21.stream.Part()
    # ... add notes
    return part

if __name__ == '__main__':
    from project_template import run_pipeline_from_file
    run_pipeline_from_file(__file__)
```

---

## 📂 **Output Location**

All outputs go to `outputs/` directory:
- **Filename:** Derived from the study file (e.g., `first.py` → `first.*`)
- **Formats:**
  - `outputs/<name>.ly` - LilyPond source
  - `outputs/<name>.pdf` - Musical score
  - `outputs/<name>.midi` - Audio playback

---

## 🔧 **For Developers**

### **Creating a New Study File**

1. **Create your file** (e.g., `my_composition.py`)

2. **Add one of the three entry points:**
   ```python
   # Option 1: LilyPond string (simplest)
   SOURCE_MELODY_LILY = r"\relative c' { c4 d e f }"
   
   # OR Option 2: Programmatic composition (most powerful)
   def build_score_data():
       return {'metadata': {...}, 'parts': {...}}
   
   # OR Option 3: music21.Part
   def build_part():
       return music21.stream.Part()
   ```

3. **Add self-execution block:**
   ```python
   if __name__ == '__main__':
       from project_template import run_pipeline_from_file
       run_pipeline_from_file(__file__)
   ```

4. **Run it:**
   ```bash
   python my_composition.py
   ```

---

## ⚠️ **Backward Compatibility**

`main.py` is **deprecated** but still works for backward compatibility:

```bash
python main.py third.py   # Still works, shows deprecation warning
```

**You'll see:**
```
⚠️  DEPRECATION WARNING
main.py is deprecated. Please use the new workflow:
  OLD: python main.py <study_file>
  NEW: python <study_file>
```

The old workflow will be removed in a future version.

---

## 🎓 **Examples**

### **Example 1: Simple Melody (first.py)**
```bash
python first.py
```
**Uses:** `SOURCE_MELODY_LILY` variable  
**Outputs:** `outputs/first.{ly,pdf,midi}`

### **Example 2: Programmatic Composition (third.py)**
```bash
python third.py
```
**Uses:** `build_score_data()` function  
**Outputs:** `outputs/third.{ly,pdf,midi}`

### **Example 3: Complex Transformations (second.py)**
```bash
python second.py
```
**Uses:** `build_score_data()` with transformations  
**Note:** Currently fails due to pre-existing Chord handling bug in `music_data.py`

---

## 🐛 **Known Issues**

### **Chord Handling Bug (Pre-existing)**
**File:** `music_data.py`  
**Issue:** `extract_data_from_part()` doesn't handle Chord objects  
**Impact:** `second.py` fails with `AttributeError: 'Chord' object has no attribute 'pitch'`  
**Workaround:** Avoid using `chordify()` or fix `music_data.py` to handle `chord.pitches` instead of `chord.pitch`

---

## 📖 **Technical Details**

### **Pipeline Function Signature**
```python
def run_pipeline_from_file(file_path_str: str):
    """
    Central pipeline orchestrator with three-stations logic.
    
    Args:
        file_path_str: Path to the study file (usually __file__)
    
    Priority Order:
        1. build_score_data() function → execute
        2. SOURCE_MELODY_LILY variable → parse with lily_to_tiny_notation()
        3. build_part() function → convert to score_data
    
    Outputs:
        - outputs/<basename>.ly
        - outputs/<basename>.pdf
        - outputs/<basename>.midi
    """
```

### **Location**
`project_template.py` - Line ~140 (added October 3, 2025)

---

## ✅ **Migration Checklist**

If you have existing code using the old workflow:

- [ ] Replace `python main.py first.py` with `python first.py`
- [ ] Remove any scripts that call `main.py`
- [ ] Update documentation to reference direct execution
- [ ] Ensure study files have `if __name__ == '__main__':` block
- [ ] Test that outputs are generated correctly

---

## 🎉 **Summary**

**Old Way:**
```bash
python main.py first.py   # External launcher required
```

**New Way:**
```bash
python first.py           # Self-executing! 🎵
```

The new workflow is:
- ✅ More intuitive
- ✅ More flexible (three input types)
- ✅ Self-documenting
- ✅ Easier to maintain

---

**Questions?** Check the study files (`first.py`, `second.py`, `third.py`) for complete examples.
