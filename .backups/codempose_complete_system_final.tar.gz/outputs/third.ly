\version "2.24.1"
\header { title = "test" }
\score {
  \new Staff {
  \clef treble
  c4 d4 e4
}
  \layout { }
  \midi { }
}