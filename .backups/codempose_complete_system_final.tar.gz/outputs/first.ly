\version "2.24.1"
\header { title = "LilyPond Score" }
\score {
  \new Staff {
  \clef treble
  c2 r4 e2 fis4 e2 r4 b2. f'2. e'2. c'2. e'2 b'2 c''2
}
  \layout { }
  \midi { }
}