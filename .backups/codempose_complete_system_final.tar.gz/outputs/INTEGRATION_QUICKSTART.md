# ⚡ Integration Quick-Start Guide

**Time to Integration**: 3-4 hours  
**Risk Level**: LOW  
**Test Coverage**: 13/13 passing

---

## 🎬 Step 1: Copy Parser Files (5 minutes)

```bash
cd /workspaces/Codempose

# Copy core parser modules
cp parser_project/data_structures.py .
cp parser_project/lily_tokenizer.py .
cp parser_project/lily_token_parser.py .
cp parser_project/relative_octave_logic.py .
cp parser_project/lily_to_tiny.py .

# Copy test suite for validation
cp parser_project/test_strict.py tests/test_parser_strict.py

# Verify files copied
ls -1 lily*.py data_structures.py relative_octave_logic.py
```

---

## 🔧 Step 2: Update lilypond_parser.py (15 minutes)

**File**: `lilypond_parser.py`

**Replace the entire `parse_lilypond_to_data()` function** with this:

```python
import re
import music21
from lily_to_tiny import lily_to_tiny_notation
from music_data import extract_data_from_part

def parse_lilypond_to_data(lily_string: str, part_name: str = "Part 1") -> dict:
    """
    Parses a LilyPond shorthand string into the standard data dictionary.
    Uses the new validated parser internally.
    
    Returns:
        dict: {"metadata": {...}, "parts": {part_name: [events...]}}
    """
    # Basic sanitization
    if lily_string is None:
        lily_string = ''
    lily_string = re.sub(r"[\x00-\x08\x0b-\x0c\x0e-\x1f]+", '', lily_string)
    
    # STEP 1: Convert LilyPond → TinyNotation using new parser
    parse_result = lily_to_tiny_notation(lily_string)
    
    # STEP 2: Log warnings for debugging
    if parse_result.has_warnings():
        print(f"⚠️  Parser warnings for {part_name}:")
        for warning in parse_result.warnings:
            print(f"   - {warning}")
    
    # STEP 3: Handle parsing failures
    if not parse_result.success:
        raise ValueError(f"Failed to parse {part_name}: {'; '.join(parse_result.warnings)}")
    
    # STEP 4: Convert TinyNotation → music21 Part
    part = music21.converter.parse(f"tinynotation: {parse_result.tiny_notation}")
    
    # Handle Stream vs Part (TinyNotation may return a Score)
    if isinstance(part, music21.stream.Score) and part.parts:
        part = part.parts[0]
    elif not isinstance(part, music21.stream.Part):
        # Convert Stream to Part
        new_part = music21.stream.Part()
        for element in part.flat.notesAndRests:
            new_part.append(element)
        part = new_part
    
    # STEP 5: Attach warnings for downstream code
    if parse_result.warnings:
        part._parse_warnings = parse_result.warnings
    
    # STEP 6: Extract metadata from directives
    metadata = {
        "title": "LilyPond Score",
        "composer": "Codempose",
        "original_input": lily_string
    }
    
    # Time signature from directives
    if 'time' in parse_result.directives:
        metadata["time_signature"] = parse_result.directives['time']
    else:
        # Fallback: extract from music21 Part
        ts = part.getElementsByClass(music21.meter.TimeSignature)
        if ts:
            metadata["time_signature"] = ts[0].ratioString
    
    # Key signature from directives
    if 'key' in parse_result.directives:
        key_str = parse_result.directives['key']
        key_parts = key_str.split()
        metadata["key_signature"] = {
            "tonic": key_parts[0].upper(),
            "mode": key_parts[1] if len(key_parts) > 1 else "major"
        }
    else:
        # Fallback: extract from music21 Part
        ks = part.getElementsByClass(music21.key.Key)
        if ks:
            k = ks[0]
            metadata["key_signature"] = {
                "tonic": getattr(k, 'tonic', getattr(k, 'tonicPitch', 'C')).name,
                "mode": getattr(k, 'mode', 'major')
            }
    
    # Tempo from music21 Part (not yet in directives)
    tm = part.getElementsByClass(music21.tempo.MetronomeMark)
    if tm:
        metadata["tempo"] = int(getattr(tm[0], 'number', 0))
    
    # STEP 7: Extract events from music21 Part
    events = extract_data_from_part(part)
    
    return {
        "metadata": metadata,
        "parts": {part_name: events}
    }
```

---

## ✅ Step 3: Validate (10 minutes)

```bash
# Test 1: Run strict test suite
cd /workspaces/Codempose
python -m unittest tests/test_parser_strict.py -v
# Expected: All 13 tests PASS

# Test 2: Quick smoke test
python -c "
from lilypond_parser import parse_lilypond_to_data
result = parse_lilypond_to_data(r'\relative c\' { c4 d e f }', 'Test')
print('✅ Parser integration successful!')
print(f'Events: {len(result[\"parts\"][\"Test\"])}')
"
```

---

## 🧪 Step 4: Test with Study Files (30-60 minutes)

```bash
# Test each study file individually
python first.py
ls -lh outputs/first.pdf outputs/first.midi

python second.py  
ls -lh outputs/second.pdf outputs/second.midi

python third.py
ls -lh outputs/third.pdf outputs/third.midi
```

**Validation checklist:**
- [ ] PDF generated without errors
- [ ] MIDI generated without errors
- [ ] Visual inspection: correct pitches and octaves
- [ ] Audio playback: melody sounds correct
- [ ] No critical errors in console output

---

## 🚨 Troubleshooting

### Issue: ImportError for lily_to_tiny

**Solution**: Ensure files are in the correct location:
```bash
ls -1 lily_to_tiny.py data_structures.py
```

### Issue: TinyNotation parsing fails

**Solution**: Check the parse_result warnings:
```python
print(parse_result.format_review())
```

### Issue: Music21 Part extraction fails

**Solution**: Add debug logging:
```python
print(f"Type: {type(part)}")
print(f"Has parts: {hasattr(part, 'parts')}")
if isinstance(part, music21.stream.Score):
    print(f"Number of parts: {len(part.parts)}")
```

---

## 📋 Full Integration Checklist

- [ ] Parser files copied to main project
- [ ] `lilypond_parser.py` updated with new implementation
- [ ] Strict test suite passing (13/13)
- [ ] Smoke test successful
- [ ] `first.py` generates correct output
- [ ] `second.py` generates correct output
- [ ] `third.py` generates correct output
- [ ] PDF outputs validated (visual inspection)
- [ ] MIDI outputs validated (audio playback)
- [ ] No regressions in existing functionality
- [ ] Old parser code archived
- [ ] Documentation updated

---

## 🎯 Success Criteria

✅ **All tests passing**  
✅ **Study files generate outputs**  
✅ **No critical warnings**  
✅ **Outputs are correct (visual + audio)**

---

## 🚀 Next Steps After Integration

1. **Archive old parser**:
   ```bash
   mkdir -p archive/old_parser_$(date +%Y%m%d)
   mv lilypond_parser.py.bak archive/old_parser_$(date +%Y%m%d)/
   ```

2. **Create git tag**:
   ```bash
   git add .
   git commit -m "Integrate new parser with 13/13 tests passing"
   git tag -a v2.0-new-parser -m "Production-ready parser integration"
   ```

3. **Plan enhancements**:
   - Priority 1: Chord support (`< c e g >`)
   - Priority 2: Tuplet support (`\tuplet 3/2 { ... }`)
   - Priority 3: Advanced directives

---

## ⏱️ Estimated Timeline

- Step 1 (Copy files): **5 minutes**
- Step 2 (Update code): **15 minutes**
- Step 3 (Validate): **10 minutes**
- Step 4 (Test study files): **30-60 minutes**
- **Total**: **1-1.5 hours** (plus manual validation time)

**You're ready to go! 🚀**

