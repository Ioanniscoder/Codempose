# 🚀 Parser Integration Plan - Detailed Implementation Guide

## Executive Summary

**Status**: Ready to integrate the new parser into the main Codempose project.
**Impact**: Replaces buggy relative octave logic with tested, production-ready parser.
**Risk**: Low - new parser is a drop-in replacement with comprehensive test coverage.

---

## 📊 Current Architecture Analysis

### Existing Code Structure:

1. **`lilypond_parser.py`**: 
   - Main entry: `parse_lilypond_to_data(lily_string, part_name) -> dict`
   - Internal: `_parse_lilypond_snippet_to_part()` - THIS IS THE BUGGY CODE
   - Returns: `{"metadata": {...}, "parts": {part_name: [events...]}}`

2. **`project_template.py`**:
   - Contains `parse_lilypond_snippet(snippet) -> music21.stream.Part`
   - Used by tools in `tools/` directory
   - Also has buggy relative octave logic

3. **Usage Points**:
   - `first.py`, `second.py`, `third.py` - study files
   - `tests/test_first.py`, `tests/test_parsing.py`
   - Tools: `inspect_parts.py`, `render_snippets.py`, `compare_tokens.py`

### New Parser Structure:

- **Entry Point**: `lily_to_tiny_notation(lily_snippet) -> ParseResult`
- **Output**: Clean TinyNotation string ready for music21
- **Metadata**: Warnings, token details, directives

---

## 🔧 Step 1: Integration Strategy

### Option A: **Minimal Disruption** (RECOMMENDED)

Replace the internal parsing logic while preserving the existing API:

```python
# In lilypond_parser.py
from parser_project.lily_to_tiny import lily_to_tiny_notation
import music21

def parse_lilypond_to_data(lily_string: str, part_name: str = "Part 1") -> dict:
    """
    Parses a LilyPond shorthand string into the standard data dictionary.
    Uses the new validated parser internally.
    """
    # Step 1: Use new parser to convert LilyPond → TinyNotation
    parse_result = lily_to_tiny_notation(lily_string)
    
    # Step 2: Log parsing review for debugging
    if parse_result.has_warnings():
        print(f"⚠️  Parser Warnings for {part_name}:")
        for warning in parse_result.warnings:
            print(f"   - {warning}")
    
    if not parse_result.success:
        # Fallback or error handling
        raise ValueError(f"Failed to parse {part_name}: {parse_result.warnings}")
    
    # Step 3: Convert TinyNotation → music21 Part
    part = music21.converter.parse(f"tinynotation: {parse_result.tiny_notation}")
    
    # Step 4: Attach warnings for downstream code
    if parse_result.warnings:
        part._parse_warnings = parse_result.warnings
    
    # Step 5: Extract metadata from ParseResult
    metadata = {"title": "LilyPond Score", "composer": "Codempose"}
    
    # Add time signature if present in directives
    if 'time' in parse_result.directives:
        metadata["time_signature"] = parse_result.directives['time']
    
    # Add key signature if present
    if 'key' in parse_result.directives:
        metadata["key_signature"] = {
            "tonic": parse_result.directives['key'].split()[0],
            "mode": parse_result.directives['key'].split()[1] if len(parse_result.directives['key'].split()) > 1 else 'major'
        }
    
    # Step 6: Extract events from music21 Part
    from music_data import extract_data_from_part
    events = extract_data_from_part(part)
    
    return {
        "metadata": metadata,
        "parts": {part_name: events}
    }
```

### Option B: **Clean Break**

Create a new module `lily_parser_v2.py` with the new implementation, then gradually migrate.

**RECOMMENDATION**: Use Option A for immediate bug fixes, then refactor later if needed.

---

## 📝 Step 2: File Migration Checklist

### Files to Copy:

```bash
# Copy parser modules to main project
cp parser_project/data_structures.py .
cp parser_project/lily_tokenizer.py .
cp parser_project/lily_token_parser.py .
cp parser_project/relative_octave_logic.py .
cp parser_project/lily_to_tiny.py .

# Copy tests for validation
cp parser_project/test_strict.py tests/
```

### Files to Update:

1. **`lilypond_parser.py`** - Replace `_parse_lilypond_snippet_to_part()` implementation
2. **`project_template.py`** - Update `parse_lilypond_snippet()` to use new parser
3. **`tests/test_first.py`** - Add validation for correct octave resolution
4. **`tests/test_parsing.py`** - Update to use new parser

---

## 🧪 Step 3: Testing Strategy

### Phase 1: Unit Tests

```bash
# Run the strict test suite to confirm parser still works
cd parser_project
python -m unittest test_strict.py -v
# Expected: All 13 tests PASS
```

### Phase 2: Integration Tests

```bash
# Test with existing test files
python -m pytest tests/test_first.py -v
python -m pytest tests/test_parsing.py -v
```

### Phase 3: End-to-End Tests

```bash
# Test with real study files
python first.py
python second.py
python third.py

# Verify outputs
ls -lh outputs/*.pdf
ls -lh outputs/*.midi
```

### Phase 4: Validation

1. **Visual Inspection**: Open PDFs, check for correct pitches and octaves
2. **Audio Validation**: Play MIDI files, listen for correct melodies
3. **Compare with Expected**: Check against known-good outputs (if available)

---

## 🧹 Step 4: Cleanup Plan

### After Successful Integration:

1. **Archive Old Parser**:
   ```bash
   mkdir -p archive/old_parser_$(date +%Y%m%d)
   mv lilypond_parser.py.bak archive/old_parser_$(date +%Y%m%d)/
   ```

2. **Remove Parser Project**:
   ```bash
   # Only after confirming integration works!
   tar -czf archive/parser_project_complete_$(date +%Y%m%d).tar.gz parser_project/
   # rm -rf parser_project/  # Optional: keep for reference
   ```

3. **Update Documentation**:
   - Update README.md with new parser architecture
   - Document supported features and limitations
   - Add usage examples

---

## 🌟 Step 5: Future Enhancements

### Priority 1: Chord Support

**Complexity**: Medium  
**Value**: High (required for harmony parts)

Implementation approach:
- Extend `lily_tokenizer.py` to recognize `< >` chord syntax
- Update `lily_token_parser.py` to handle multiple pitches per token
- Modify `format_as_tiny_notation()` to output chord notation

### Priority 2: Tuplet Support

**Complexity**: High  
**Value**: Medium (required for triplets, swing rhythms)

Implementation approach:
- Add tuplet directive parsing in tokenizer
- Implement tuplet duration calculation
- Handle nested tuplets

### Priority 3: Advanced Directives

**Complexity**: Low-Medium  
**Value**: Low (nice-to-have for completeness)

Directives to add:
- `\tempo` - tempo markings
- `\clef` - clef changes
- `\override` - styling directives

---

## ⚠️ Risk Assessment

### Low Risk:
- Parser has 13 passing tests
- Modular design allows incremental integration
- Existing API can be preserved

### Medium Risk:
- Integration with `music_data.extract_data_from_part()` needs validation
- Some edge cases in study files may reveal new issues

### Mitigation:
- Keep old parser code for fallback
- Test incrementally with study files
- Monitor for warnings in production use

---

## 📋 Integration Checklist

- [ ] Copy parser files to main project
- [ ] Update imports in `lilypond_parser.py`
- [ ] Replace `_parse_lilypond_snippet_to_part()` implementation
- [ ] Update `project_template.py` if needed
- [ ] Run strict test suite (13 tests)
- [ ] Run integration tests
- [ ] Test with `first.py`
- [ ] Test with `second.py`
- [ ] Test with `third.py`
- [ ] Validate PDF outputs
- [ ] Validate MIDI outputs
- [ ] Archive old parser code
- [ ] Update documentation
- [ ] Deploy to production

---

## 🎯 Success Criteria

✅ All 13 strict tests passing  
✅ Integration tests passing  
✅ Study files generate correct output  
✅ No regressions in existing functionality  
✅ Warnings logged appropriately  
✅ Code is maintainable and documented

---

## 🚦 Next Action

**Immediate**: Run Step 1 (file copy and basic integration)  
**Then**: Run Step 3 (testing strategy)  
**Finally**: Execute Step 4 (cleanup) only after full validation

