\version "2.24.1"
\header { title = "Fourth Study - Two Staves in A Minor" }
\score {
  <<
\new Staff {
  \clef bass
  <e>4 <b>4 <c'>4 <a>4 <e'>4 <f'>4 <e'>4 <a>4 <gis>4
}\new Staff {
  \clef treble
  e4 b4 c'4 a4 e'4 f'4 e'4 a4 gis4
}
>>
  \layout { }
  \midi { }
}