# project_template.py

import music21
import abjad
from pathlib import Path
import subprocess
import re
from fractions import Fraction

def ql_to_lily_duration_string(ql: float) -> str:
    # Try the exact representation first (fraction of whole note)
    frac = Fraction(ql).limit_denominator(1024)
    try:
        dur = abjad.Duration(Fraction(frac, 4))
        return dur.lilypond_duration_string
    except Exception:
        # Fall back: approximate with power-of-two base durations and dots
        candidates = []
        # LilyPond duration numbers (1,2,4,8,16...) correspond to whole-note denominators
        bases = [1, 2, 4, 8, 16, 32, 64]
        for base in bases:
            for dots in range(0, 4):
                factor = 2 - 1 / (2 ** dots) if dots > 0 else 1
                ql_candidate = 4 / base * factor
                diff = abs(ql_candidate - float(ql))
                candidates.append((diff, base, dots, ql_candidate))
        candidates.sort(key=lambda x: x[0])
        best = candidates[0]
        diff, base, dots, ql_candidate = best
        # Build lilypond duration string (e.g. 4., 8..)
        dur_str = str(base) + ('.' * dots)
        if diff > 1e-2:
            print(f"[warning] approximate duration: requested ql={ql} approximated as {ql_candidate} (LilyPond: {dur_str}); diff={diff}")
        return dur_str

def _parse_token(tok: str):
    if tok.lower().startswith('r'):
        m = re.match(r"r(\d+\.?)", tok, re.IGNORECASE)
        dur_token = m.group(1) if m else '4'
        ql = 4.0 / float(dur_token.replace('.', ''))
        if '.' in dur_token: ql *= 1.5
        return music21.note.Rest(quarterLength=ql)

    m = re.match(r"(?P<step>[a-g])(?P<acc>(?:is|es|s|b|#)?)(?P<oct>[,']*)(?P<dur>\d+\.?)?", tok, flags=re.IGNORECASE)
    if not m: return None
    
    data = m.groupdict()
    p = music21.pitch.Pitch(data['step'])
    acc_str = (data['acc'] or '').lower()
    if 'is' in acc_str or '#' in acc_str: p.accidental = '#'
    if 'es' in acc_str or 's' in acc_str: p.accidental = 'b'
    if 'b' in acc_str: p.accidental = 'b'
    
    p.octave = 4 + (data['oct'] or '').count("'") - (data['oct'] or '').count(",")
    dur_token = data['dur'] or '4'
    ql = 4.0 / float(dur_token.replace('.', ''))
    if '.' in dur_token: ql *= 1.5
    return music21.note.Note(p, quarterLength=ql)

def _resolve_relative(tok: str, last_pitch: music21.pitch.Pitch):
    element = _parse_token(tok)
    if not isinstance(element, music21.note.Note) or "'" in tok or "," in tok:
        return element
    element.pitch.octave = last_pitch.octave
    interval = music21.interval.Interval(last_pitch, element.pitch)
    if interval.direction == music21.interval.Direction.ASCENDING and interval.semitones > 6:
        element.pitch.octave -= 1
    elif interval.direction == music21.interval.Direction.DESCENDING and interval.semitones < -6:
        element.pitch.octave += 1
    return element
    
def parse_lilypond_snippet(snippet: str) -> music21.stream.Part:
    part = music21.stream.Part()
    relative_match = re.match(r"\\relative\s+([a-g][^ ]*)?\s*\{(.*)\}", snippet, re.DOTALL | re.IGNORECASE)
    if not relative_match: raise ValueError("Parser requires a \\relative block.")
    base_note_str, body = relative_match.groups()
    body = re.sub(r"\\(time|key|major|minor|tempo)\s+[^|\s}]+", "", body, re.IGNORECASE)
    body = body.replace("bmol", "b").replace("f#", "fis")
    tokens = [tok for tok in body.split() if tok != '|']
    last_note = _parse_token(base_note_str)
    if not isinstance(last_note, music21.note.Note): raise ValueError(f"Invalid base note: {base_note_str}")
    last_pitch = last_note.pitch
    for tok in tokens:
        element = _resolve_relative(tok, last_pitch)
        if element:
            part.append(element)
            if isinstance(element, music21.note.Note): last_pitch = element.pitch
    return part

def engrave_with_abjad(score_data: dict, output_basename: str):
    print(f"🎶 Engraving '{score_data.get('metadata', {}).get('title', '')}'...")
    out_dir = Path('outputs'); out_dir.mkdir(parents=True, exist_ok=True)
    ly_path = out_dir / f"{output_basename}.ly"
    title = score_data.get('metadata', {}).get('title', output_basename)

    staves = []
    for part_name, events in sorted(score_data.get('parts', {}).items()):
        # Always reconstruct from event data (don't use original_input)
        # This ensures proper accidental normalization and chord support
        part_tokens = []
        for ev in events:
            ql = ev.get('ql', 1.0)
            dur_str = ql_to_lily_duration_string(ql)
            if ev.get('type') == 'rest':
                part_tokens.append(f"r{dur_str}")
            elif ev.get('type') == 'chord':
                # Handle chord events - format as <pitch1 pitch2 pitch3>duration
                chord_pitches = []
                for pitch_data in ev.get('pitches', []):
                    step = pitch_data.get('step', 'c').lower()
                    alter = pitch_data.get('alter', 0)
                    acc = ''
                    if alter == 1: acc = 'is'
                    elif alter == -1: acc = 'es'
                    octave = pitch_data.get('octave', 4)
                    if octave == 4:
                        pitch_text = f"{step}{acc}"
                    elif octave > 4:
                        marks = "'" * (octave - 4)
                        pitch_text = f"{step}{acc}{marks}"
                    else:
                        marks = "," * (4 - octave)
                        pitch_text = f"{step}{acc}{marks}"
                    chord_pitches.append(pitch_text)
                chord_str = f"<{' '.join(chord_pitches)}>{dur_str}"
                part_tokens.append(chord_str)
            elif ev.get('type') == 'note':
                step = ev.get('step', 'c').lower()
                alter = ev.get('alter', 0)
                acc = ''
                if alter == 1: acc = 'is'
                elif alter == -1: acc = 'es'
                octave = ev.get('octave', 4)
                if octave == 4:
                    pitch_text = f"{step}{acc}"
                elif octave > 4:
                    marks = "'" * (octave - 4)
                    pitch_text = f"{step}{acc}{marks}"
                else:
                    marks = "," * (4 - octave)
                    pitch_text = f"{step}{acc}{marks}"
                part_tokens.append(f"{pitch_text}{dur_str}")
        body = " ".join(part_tokens)
        clef = "bass" if "harmony" in part_name.lower() else "treble"
        staves.append(f"\\new Staff {{\n  \\clef {clef}\n  {body}\n}}")
    score_block = f"<<\n{''.join(staves)}\n>>" if len(staves) > 1 else staves[0]

    ly_content = f'\\version "2.24.1"\n\\header {{ title = "{title}" }}\n\\score {{\n  {score_block}\n  \\layout {{ }}\n  \\midi {{ }}\n}}'
    ly_path.write_text(ly_content)
    print(f"Wrote LilyPond file: {ly_path}")
    try:
        subprocess.run(["lilypond", str(ly_path.name)], cwd=str(out_dir), capture_output=True, text=True, check=True)
        print(f"✅ Successfully compiled {output_basename}.pdf and .midi")
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"⚠️ Could not compile with LilyPond. Error:\n{getattr(e, 'stderr', e)}")


def run_pipeline_from_file(file_path_str: str):
    """
    Central pipeline orchestrator - the "three stations" approach.
    
    This function implements flexible input handling with priority order:
    1. build_score_data() function - for programmatic composition
    2. SOURCE_MELODY_LILY variable - for raw LilyPond strings
    3. build_part() function - for music21.Part generation
    
    The result is automatically engraved to PDF/MIDI in the outputs/ directory.
    
    Args:
        file_path_str: Path to the study file (usually __file__ from the caller)
    """
    import importlib.util
    import re
    from pathlib import Path
    
    # Resolve file path
    file_path = Path(file_path_str).resolve()
    if not file_path.exists():
        raise FileNotFoundError(f"Study file not found: {file_path}")
    
    # Derive output basename from filename (e.g., first.py → first)
    output_basename = file_path.stem
    
    print(f"\n{'='*60}")
    print(f"🎵 CODEMPOSE PIPELINE")
    print(f"{'='*60}")
    print(f"Study file: {file_path.name}")
    print(f"Output: outputs/{output_basename}.*")
    print(f"{'='*60}\n")
    
    # Load the study file as a Python module
    spec = importlib.util.spec_from_file_location(file_path.stem, str(file_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {file_path}")
    
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    
    score_data = None
    input_type = None
    
    # Station 1: Try build_score_data() - highest priority
    if hasattr(module, 'build_score_data'):
        print("📊 Found build_score_data() function")
        input_type = "build_score_data"
        try:
            result = module.build_score_data()
            # Handle case where build_score_data returns score_data dict
            if isinstance(result, dict) and 'parts' in result:
                score_data = result
            # Handle case where it returns a music21.Part
            elif hasattr(result, '__class__') and 'Part' in result.__class__.__name__:
                print("   Converting Part to score_data...")
                from music_data import extract_data_from_part
                events = extract_data_from_part(result)
                score_data = {
                    'metadata': {'title': output_basename},
                    'parts': {'Main': events}
                }
            else:
                raise ValueError(f"build_score_data() returned unexpected type: {type(result)}")
        except Exception as e:
            print(f"❌ Error executing build_score_data(): {e}")
            import traceback
            traceback.print_exc()
            raise
    
    # Station 2: Try SOURCE_MELODY_LILY - second priority
    elif hasattr(module, 'SOURCE_MELODY_LILY'):
        print("📝 Found SOURCE_MELODY_LILY variable")
        input_type = "SOURCE_MELODY_LILY"
        lily_string = getattr(module, 'SOURCE_MELODY_LILY')
        print(f"   LilyPond input: {lily_string[:60]}...")
        
        # Use the integrated parser
        from lilypond_parser import parse_lilypond_to_data
        try:
            score_data = parse_lilypond_to_data(lily_string, part_name='Melody')
            # Update title if not set
            if 'metadata' not in score_data:
                score_data['metadata'] = {}
            if 'title' not in score_data['metadata']:
                score_data['metadata']['title'] = output_basename
        except Exception as e:
            print(f"❌ Error parsing SOURCE_MELODY_LILY: {e}")
            import traceback
            traceback.print_exc()
            raise
    
    # Station 3: Try build_part() - third priority
    elif hasattr(module, 'build_part'):
        print("🎼 Found build_part() function")
        input_type = "build_part"
        try:
            part = module.build_part()
            print("   Converting Part to score_data...")
            from music_data import extract_data_from_part
            events = extract_data_from_part(part)
            score_data = {
                'metadata': {'title': output_basename},
                'parts': {'Main': events}
            }
        except Exception as e:
            print(f"❌ Error executing build_part(): {e}")
            import traceback
            traceback.print_exc()
            raise
    
    # No valid entry point found
    else:
        raise AttributeError(
            f"Study file {file_path.name} must contain one of:\n"
            f"  1. build_score_data() function (highest priority)\n"
            f"  2. SOURCE_MELODY_LILY variable\n"
            f"  3. build_part() function"
        )
    
    # Display what we found
    print(f"✅ Successfully loaded via: {input_type}")
    print(f"   Metadata: {score_data.get('metadata', {})}")
    print(f"   Parts: {list(score_data.get('parts', {}).keys())}")
    
    # Show warnings if any
    warnings = score_data.get('metadata', {}).get('warnings', [])
    if warnings:
        print(f"\n⚠️  Parser warnings:")
        for w in warnings:
            print(f"   - {w}")
    
    print()
    
    # Station 4: Engrave
    engrave_with_abjad(score_data, output_basename)
    
    print(f"\n{'='*60}")
    print(f"✅ PIPELINE COMPLETE")
    print(f"{'='*60}")
    print(f"Generated files:")
    print(f"  • outputs/{output_basename}.ly   (LilyPond source)")
    print(f"  • outputs/{output_basename}.pdf  (Musical score)")
    print(f"  • outputs/{output_basename}.midi (Audio playback)")
    print(f"{'='*60}\n")