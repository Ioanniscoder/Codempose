\version "2.24.1"
% ========================================
% GENERATED FROM: thirteenth.py
% ========================================
%
% ========================================
% ORIGINAL SNIPPETS (Station 1 & 2)
% ========================================
%
% LilyPond Format:
%   INTERMEZZO:
%     
\relative c' {
    \time 4/4
    \key c \major
    <c e g>2 <d f a>2 |
    <e g b>2 <f a c>2
}

%
%   THEME_A:
%     
\relative c' {
    \time 4/4
    \key c \major
    \tempo 4=120
    c4 [d e f]8 e4~ e4 |
    ~g16 a2(p) [b c d]8 c4~ c4 |
    [e f g]8 f4 e2 d4 |
    ~c16 e2~ e4 r2
}

%
%   THEME_B:
%     
\relative c' {
    \time 4/4
    \key c \major
    c4(., themeB) d4(-, p) e4(>, mf) f4(themeB) |
    g4(., f) a4(-) b4(>, ff) c4(themeB, >) |
    c4(p) b4(mp) a4(mf) g4(f) |
    f4(., themeB) e4(-, p) d4 c4(themeB)
}

%
%   THEME_C:
%     
\relative c' {
    \time 4/4
    \key c \major
    ~g16(f, themeC) [c4(., p) d4(-, mp) e4(>, mf)]8 |
    f4(themeC, .)~ f4 [g4(p) a4(mf)]8 |
    ~b16(ff) c4(themeC, >, ff)~ c4 b4(., p) |
    a4(themeC) g4(-, mp) f4(.) e4(themeC, p)
}

%
% TinyNotation Format:
%   INTERMEZZO:
%     tinynotation: 4/4 <c e g>2 <d f a>2 <e g b>2 <f a c>2
%
%   THEME_A:
%     tinynotation: 4/4 c4 d8 e8 f8 e4~ e4 g16grace a2 b8 c8 d8 c4~ c4 e8 f8 g8 f4 e2 d4 c16grace e2~ e4 r2
%
%   THEME_B:
%     tinynotation: 4/4 c4. d4- e4> f4 g4. a4- b4> c4> c4 b4 a4 g4 f4. e4- d4 c4
%
%   THEME_C:
%     tinynotation: 4/4 g16grace c4. d4- e4> f4.~ f4 g4 a4 b16grace c4>~ c4 b4. a4 g4- f4. e4
%
% ========================================
% SHORTHAND STRUCTURE (Station 3)
% ========================================
%
%   MainLine.Finale_A: THEME_A_HARMONY
%   MainLine.Finale_B: THEME_B_HARMONY
%   MainLine.Finale_C: THEME_C_HARMONY
%   MainLine.Intermezzo_1: HARMONY_1
%   MainLine.Intermezzo_2: HARMONY_1
%   MainLine.Intermezzo_3: HARMONY_2
%   MainLine.Intermezzo_4: HARMONY_2
%   MainLine.Intermezzo_5: HARMONY_2
%   MainLine.Intermezzo_6: HARMONY_3
%   MainLine.Intermezzo_7: HARMONY_3
%   MainLine.Intermezzo_8: HARMONY_3
%   MainLine.Intermezzo_9: HARMONY_1
%   MainLine.ThemeA_Inverted: THEME_A_INVERTED_C4
%   MainLine.ThemeA_Original: THEME_A
%   MainLine.ThemeA_Transposed: THEME_A_TRANSPOSED_P5
%   MainLine.ThemeB_Augmented: THEME_B_AUGMENTED
%   MainLine.ThemeB_Original: THEME_B
%   MainLine.ThemeB_Retrograde: THEME_B_RETROGRADE
%   MainLine.ThemeC_Diminished: THEME_C_DIMINISHED
%   MainLine.ThemeC_OctaveUp: THEME_C_OCTAVE_UP
%   MainLine.ThemeC_Original: THEME_C
%
% ========================================
% VOICE TRACKING (Station 4 - Detailed)
% ========================================
%
% 01_ThemeA_Original:
%   Transformation: identity
%   Description: Original theme with tuplets, ties, grace notes
%   Events: 20
%   Source: THEME_A_LILY
%
% 02_Intermezzo_1:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 03_ThemeA_Transposed:
%   Transformation: transpose(P5)
%   Description: Theme A transposed up perfect fifth
%   Events: 20
%   Source: THEME_A_LILY
%
% 04_Intermezzo_2:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 05_ThemeA_Inverted:
%   Transformation: invert(center=C4)
%   Description: Theme A melodically inverted around C4
%   Events: 20
%   Source: THEME_A_LILY
%
% 06_Intermezzo_3:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 07_ThemeB_Original:
%   Transformation: identity
%   Description: Original theme with articulations, dynamics, tracking
%   Events: 16
%   Source: THEME_B_LILY
%
% 08_Intermezzo_4:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 09_ThemeB_Retrograde:
%   Transformation: retrograde()
%   Description: Theme B in reverse order
%   Events: 16
%   Source: THEME_B_LILY
%
% 10_Intermezzo_5:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 11_ThemeB_Augmented:
%   Transformation: augment(factor=2.0)
%   Description: Theme B with doubled durations
%   Events: 16
%   Source: THEME_B_LILY
%
% 12_Intermezzo_6:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 13_ThemeC_Original:
%   Transformation: identity
%   Description: Original theme with ALL features combined
%   Events: 14
%   Source: THEME_C_LILY
%
% 14_Intermezzo_7:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 15_ThemeC_Diminished:
%   Transformation: diminish(factor=2.0)
%   Description: Theme C with halved durations
%   Events: 14
%   Source: THEME_C_LILY
%
% 16_Intermezzo_8:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 17_ThemeC_OctaveUp:
%   Transformation: transpose(P8)
%   Description: Theme C transposed up one octave
%   Events: 14
%   Source: THEME_C_LILY
%
% 18_Intermezzo_9:
%   Transformation: identity
%   Description: Harmonic interlude (chords)
%   Events: 0
%   Source: INTERMEZZO_LILY
%
% 19_Finale_A:
%   Transformation: chordify()
%   Description: Theme A harmonized (triadic chords)
%   Events: 20
%   Source: THEME_A_LILY
%
% 20_Finale_B:
%   Transformation: chordify()
%   Description: Theme B harmonized (triadic chords)
%   Events: 16
%   Source: THEME_B_LILY
%
% 21_Finale_C:
%   Transformation: chordify()
%   Description: Theme C harmonized (triadic chords)
%   Events: 14
%   Source: THEME_C_LILY
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Thirteenth Study: Complete Parser Feature Showcase" }
\score {
  \new Staff {
  \clef treble
  \time 4/4
  c''4 d''16. e''16. f''16. e''2 g''64 a''2\p b''16. c'''16. d'''16. c'''2 e'''16. f'''16. g'''16. f'''4 e'''2 d'''4 c'''64 e'''2. r2 \bar "||" \bar "||" g''4 a''16. b''16. c'''16. b''2 d'''4 e'''2 fis'''16. g'''16. a'''16. g'''2 b'''16. c''''16. d''''16. c''''4 b'''2 a'''4 g'''4 b'''2. r2 \bar "||" \bar "||" c'4 bes'16. aes'16. g'16. aes'2 f'4 ees'2 des'16. c'16. bes'16. c'2 aes'16. g'16. f'16. g'4 aes'2 bes'4 c'4 aes'2. r2 \bar "||" \bar "||" c''4-. d''4--\p e''4->\mf f''4 g''4-.\f a''4-- b''4->\ff c'''4-> c'''4\p b''4\mp a''4\mf g''4\f f''4-. e''4--\p d''4 c''4 \bar "||" \bar "||" c''4 d''4 e''4 f''4 g''4 a''4 b''4 c'''4 c'''4 b''4 a''4 g''4 f''4 e''4 d''4 c''4 \bar "||" \bar "||" c''2 d''2 e''2 f''2 g''2 a''2 b''2 c'''2 c'''2 b''2 a''2 g''2 f''2 e''2 d''2 c''2 \bar "||" \bar "||" g'64\f c''8. d''8. e''8. f''2-. g''8 a''8 b''64\ff c'''2->\ff b''4-.\p a''4 g''4--\mp f''4-. e''4\p \bar "||" \bar "||" g'8 c''16. d''16. e''16. f''4 g''16 a''16 b''8 c'''4 b''8 a''8 g''8 f''8 e''8 \bar "||" \bar "||" g''4 c'''8. d'''8. e'''8. f'''2 g'''8 a'''8 b'''4 c''''2 b'''4 a'''4 g'''4 f'''4 e'''4 \bar "||" \bar "||" <c'' e'' g''>4 <d'' fis'' a''>16. <e'' gis'' b''>16. <f'' a'' c'''>16. <e'' gis'' b''>2 <g'' b'' d'''>4 <a'' cis''' e'''>2 <b'' dis''' fis'''>16. <c''' e''' g'''>16. <d''' fis''' a'''>16. <c''' e''' g'''>2 <e''' gis''' b'''>16. <f''' a''' c''''>16. <g''' b''' d''''>16. <f''' a''' c''''>4 <e''' gis''' b'''>2 <d''' fis''' a'''>4 <c''' e''' g'''>4 <e''' gis''' b'''>2. r2 \bar "||" <c'' e'' g''>4 <d'' fis'' a''>4 <e'' gis'' b''>4 <f'' a'' c'''>4 <g'' b'' d'''>4 <a'' cis''' e'''>4 <b'' dis''' fis'''>4 <c''' e''' g'''>4 <c''' e''' g'''>4 <b'' dis''' fis'''>4 <a'' cis''' e'''>4 <g'' b'' d'''>4 <f'' a'' c'''>4 <e'' gis'' b''>4 <d'' fis'' a''>4 <c'' e'' g''>4 \bar "||" <g' b' d''>4 <c'' e'' g''>8. <d'' fis'' a''>8. <e'' gis'' b''>8. <f'' a'' c'''>2 <g'' b'' d'''>8 <a'' cis''' e'''>8 <b'' dis''' fis'''>4 <c''' e''' g'''>2 <b'' dis''' fis'''>4 <a'' cis''' e'''>4 <g'' b'' d'''>4 <f'' a'' c'''>4 <e'' gis'' b''>4
}
  \layout { }
  \midi { }
}