\version "2.24.1"
% ========================================
% GENERATED FROM: test_export.py
% ========================================
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Articulation & Dynamics Test" }
\score {
  \new Staff {
  \clef treble
  \time 4/4 \tempo 4 = 120
  c''4-. d''4--\p e''4->\mf f''4 g''4-.\f a''4--\ff b''4 c''''4-.\p
}
  \layout { }
  \midi { }
}