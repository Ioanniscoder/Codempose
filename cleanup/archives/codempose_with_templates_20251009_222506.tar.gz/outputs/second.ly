\version "2.24.1"
% ========================================
% ORIGINAL LILYPOND INPUT (for reference)
% ========================================
% \relative c' { \time 4/4 \key c \major e4 b4 e'4 b4 }
%
% ========================================

\header { title = "LilyPond Score" }
\score {
  <<
\new Staff {
  \clef treble
  \time 4/4
  e4 b4 e''4 b''4 b4 fis'4 b''4 fis'''4 e'4 ees'4 bes4 ees'4 fis'''4 b''4 fis'4 b4
}\new Staff {
  \clef bass
  \time 4/4
  <e>4 <b>4 <e''>4 <b''>4 <b>4 <fis'>4 <b''>4 <fis'''>4 <e'>4 <ees'>4 <bes>4 <ees'>4 <fis'''>4 <b''>4 <fis'>4 <b>4
}
>>
  \layout { }
  \midi { }
}