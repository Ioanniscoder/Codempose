\version "2.24.1"
% ========================================
% GENERATED FROM: twelfth.py
% ========================================
%
% ========================================
% ORIGINAL SNIPPETS (Station 1 & 2)
% ========================================
%
% LilyPond Format:
%   SOURCE_MELODY:
%     \relative e { \time 6/4 \key c \major \tempo 4=90 e2 b4 c2 r4 | e2 f4 e2 r4 | b2. f2. | e2. c2. | e2 b2 c2 }
%
% TinyNotation Format:
%   SOURCE_MELODY:
%     tinynotation: 6/4 e2 b,4 c2 r4 e2 f4 e2 r4 b,2. f2. e2. c2. e2 b,2 c2
%
% ========================================
% TINYNOTATION INSPECTOR (Diagnostic)
% ========================================
% This TinyNotation string shows how the parser
% resolved relative pitches. Use it to verify
% octave resolution is working correctly.
%
%   6/4 e2 b,4 c2 r4 e2 f4 e2 r4 b,2. f2. e2. c2. e2 b,2 c2
%
% ========================================
% SHORTHAND STRUCTURE (Station 3)
% ========================================
%
%   SingleLine.Augmented_x2: SNIPPET_AUGMENTED
%   SingleLine.Diminished_x0.5: SNIPPET_DIMINISHED
%   SingleLine.Intermezzo_1: HARMONY
%   SingleLine.Intermezzo_2: HARMONY
%   SingleLine.Intermezzo_3: HARMONY
%   SingleLine.Intermezzo_4: HARMONY
%   SingleLine.Intermezzo_5: HARMONY
%   SingleLine.Intermezzo_6: HARMONY
%   SingleLine.Intermezzo_7: HARMONY
%   SingleLine.Inverted_C4: SNIPPET_INVERTED_C4
%   SingleLine.Octave_Down: SNIPPET_OCTAVE_DOWN
%   SingleLine.Octave_Up: SNIPPET_OCTAVE_UP
%   SingleLine.Original: SNIPPET
%   SingleLine.Retrograde: SNIPPET_RETROGRADE
%   SingleLine.Transposed_P5: SNIPPET_TRANSPOSED_P5
%
% ========================================
% VOICE TRACKING (Station 4 - Detailed)
% ========================================
%
% 01_Original:
%   Transformation: identity
%   Description: Original melodic snippet
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 02_Harmony_1:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 03_Transposed_P5:
%   Transformation: transpose(P5)
%   Description: Transposed up by perfect fifth
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 04_Harmony_2:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 05_Inverted_C4:
%   Transformation: invert(center=C4)
%   Description: Melodic inversion around C4
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 06_Harmony_3:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 07_Retrograde:
%   Transformation: retrograde()
%   Description: Reversed note order
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 08_Harmony_4:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 09_Augmented_x2:
%   Transformation: augment(factor=2.0)
%   Description: Durations doubled
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 10_Harmony_5:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 11_Diminished_x0.5:
%   Transformation: diminish(factor=2.0)
%   Description: Durations halved
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 12_Harmony_6:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 13_Octave_Up:
%   Transformation: transpose(P8)
%   Description: Transposed up one octave
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 14_Harmony_7:
%   Transformation: harmonize (root + M3 + P5)
%   Description: Harmony intermezzo (triadic chords)
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% 15_Octave_Down:
%   Transformation: transpose(-P8)
%   Description: Transposed down one octave
%   Events: 15
%   Source: SOURCE_MELODY_LILY
%
% ========================================
% HOW TO USE
% ========================================
% - Copy any snippet above into a new study file
% - Use shorthand expressions as templates
% - Programmatic voices can be edited or transformed
% ========================================
\header { title = "Twelfth Study: All Transformations" }
\score {
  \new Staff {
  \clef treble
  \time 6/4
  e'2 b4 c'2 r4 e'2 f'4 e'2 r4 b2. f'2. e'2. c'2. e'2 b2 c'2 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" b'2 fis'4 g'2 r4 b'2 c''4 b'2 r4 fis'2. c''2. b'2. g'2. b'2 fis'2 g'2 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" aes'2 b'4 c''2 r4 aes'2 g'4 aes'2 r4 b'2. g'2. aes'2. c''2. aes'2 b'2 c''2 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" c'2 b2 e'2 c'2. e'2. f'2. b2. r4 e'2 f'4 e'2 r4 c'2 b4 e'2 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" e'1 b2 c'1 r2 e'1 f'2 e'1 r2 b1. f'1. e'1. c'1. e'1 b1 c'1 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" e'4 b8 c'4 r8 e'4 f'8 e'4 r8 b4. f'4. e'4. c'4. e'4 b4 c'4 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" e''2 b'4 c''2 r4 e''2 f''4 e''2 r4 b'2. f''2. e''2. c''2. e''2 b'2 c''2 \bar "||" <e' gis' b'>2 <b dis' fis'>4 <c' e' g'>2 r4 <e' gis' b'>2 <f' a' c''>4 <e' gis' b'>2 r4 <b dis' fis'>2. <f' a' c''>2. <e' gis' b'>2. <c' e' g'>2. <e' gis' b'>2 <b dis' fis'>2 <c' e' g'>2 \bar "||" e2 b,4 c2 r4 e2 f4 e2 r4 b,2. f2. e2. c2. e2 b,2 c2
}
  \layout { }
  \midi { }
}